// Full Game Flow Integration Tests
import { 
  assignRoles, 
  getTeamSize, 
  determineQuestResult,
  checkWinner,
  determineVoteResult,
  checkEvilWinsByRejections,
  getNextLeaderIndex,
  requiresTwoFails
} from '@/lib/gameLogic';
import type { Role } from '@/types';

// Simple test framework
let passed = 0;
let failed = 0;

function describe(name: string, fn: () => void) {
  console.log(`\n📦 ${name}`);
  fn();
}

function test(name: string, fn: () => void) {
  try {
    fn();
    console.log(`  ✅ ${name}`);
    passed++;
  } catch (err) {
    console.log(`  ❌ ${name}`);
    console.log(`     Error: ${err}`);
    failed++;
  }
}

function expect(actual: any) {
  return {
    toBe(expected: any) {
      if (actual !== expected) {
        throw new Error(`Expected ${expected} but got ${actual}`);
      }
    },
    toEqual(expected: any) {
      if (JSON.stringify(actual) !== JSON.stringify(expected)) {
        throw new Error(`Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
      }
    },
    toBeDefined() {
      if (actual === undefined) {
        throw new Error(`Expected value to be defined but got undefined`);
      }
    },
    toContain(item: any) {
      if (!actual.includes(item)) {
        throw new Error(`Expected array to contain ${item}`);
      }
    },
    not: {
      toContain(item: any) {
        if (actual.includes(item)) {
          throw new Error(`Expected array NOT to contain ${item}`);
        }
      }
    },
    toBeNull() {
      if (actual !== null) {
        throw new Error(`Expected null but got ${actual}`);
      }
    },
    toBeTrue() {
      if (actual !== true) {
        throw new Error(`Expected true but got ${actual}`);
      }
    },
    toBeFalse() {
      if (actual !== false) {
        throw new Error(`Expected false but got ${actual}`);
      }
    }
  };
}

console.log('\n🎮 Running Full Game Flow Tests\n');

// ==================== SCENARIO 1: Good Wins 3-0 ====================
describe('Scenario 1: Good wins 3-0', () => {
  const playerCount = 5;
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  
  test('Step 1: Assign roles correctly', () => {
    const assignments = assignRoles(playerIds, selectedRoles);
    expect(Object.keys(assignments).length).toBe(5);
    
    const goodCount = Object.values(assignments).filter(a => a.team === 'good').length;
    const evilCount = Object.values(assignments).filter(a => a.team === 'evil').length;
    expect(goodCount).toBe(3);
    expect(evilCount).toBe(2);
  });
  
  test('Step 2: Quest 1 - Team of 2, all success', () => {
    expect(getTeamSize(playerCount, 0)).toBe(2);
    const cards = { p1: 'success' as const, p2: 'success' as const };
    expect(determineQuestResult(playerCount, 0, cards)).toBe('success');
  });
  
  test('Step 3: Quest 2 - Team of 3, all success', () => {
    expect(getTeamSize(playerCount, 1)).toBe(3);
    const cards = { p1: 'success' as const, p2: 'success' as const, p3: 'success' as const };
    expect(determineQuestResult(playerCount, 1, cards)).toBe('success');
  });
  
  test('Step 4: Quest 3 - Team of 2, all success', () => {
    expect(getTeamSize(playerCount, 2)).toBe(2);
    const cards = { p1: 'success' as const, p2: 'success' as const };
    expect(determineQuestResult(playerCount, 2, cards)).toBe('success');
  });
  
  test('Step 5: Good wins 3-0', () => {
    const results: ('success' | 'fail' | null)[] = ['success', 'success', 'success', null, null];
    expect(checkWinner(results)).toBe('good');
  });
});

// ==================== SCENARIO 2: Evil Wins 3-0 ====================
describe('Scenario 2: Evil wins 3-0', () => {
  const playerCount = 5;
  
  test('Quest 1 fails with 1 fail card', () => {
    const cards = { p1: 'success' as const, p2: 'fail' as const };
    expect(determineQuestResult(playerCount, 0, cards)).toBe('fail');
  });
  
  test('Quest 2 fails with 1 fail card', () => {
    const cards = { p1: 'success' as const, p2: 'success' as const, p3: 'fail' as const };
    expect(determineQuestResult(playerCount, 1, cards)).toBe('fail');
  });
  
  test('Quest 3 fails with 1 fail card', () => {
    const cards = { p1: 'success' as const, p2: 'fail' as const };
    expect(determineQuestResult(playerCount, 2, cards)).toBe('fail');
  });
  
  test('Evil wins 3-0', () => {
    const results: ('success' | 'fail' | null)[] = ['fail', 'fail', 'fail', null, null];
    expect(checkWinner(results)).toBe('evil');
  });
});

// ==================== SCENARIO 3: Good Wins 3-2 ====================
describe('Scenario 3: Good wins 3-2', () => {
  test('Quest sequence: success, fail, success, fail, success', () => {
    const results: ('success' | 'fail' | null)[] = ['success', 'fail', 'success', 'fail', 'success'];
    expect(checkWinner(results)).toBe('good');
  });
});

// ==================== SCENARIO 4: Evil Wins by Rejections ====================
describe('Scenario 4: Evil wins by 5 rejections', () => {
  test('4 rejections - game continues', () => {
    expect(checkEvilWinsByRejections(4)).toBeFalse();
  });
  
  test('5 rejections - evil wins', () => {
    expect(checkEvilWinsByRejections(5)).toBeTrue();
  });
});

// ==================== SCENARIO 5: 7 Players - Quest 4 Requires 2 Fails ====================
describe('Scenario 5: 7 players - Quest 4 special rule', () => {
  const playerCount = 7;
  
  test('Quest 4 requires 2 fails for 7 players', () => {
    expect(requiresTwoFails(playerCount, 3)).toBeTrue();
  });
  
  test('Quest 4 succeeds with 1 fail', () => {
    const cards = { 
      p1: 'success' as const, 
      p2: 'fail' as const, 
      p3: 'success' as const, 
      p4: 'success' as const 
    };
    expect(determineQuestResult(playerCount, 3, cards)).toBe('success');
  });
  
  test('Quest 4 fails with 2 fails', () => {
    const cards = { 
      p1: 'success' as const, 
      p2: 'fail' as const, 
      p3: 'fail' as const, 
      p4: 'success' as const 
    };
    expect(determineQuestResult(playerCount, 3, cards)).toBe('fail');
  });
});

// ==================== SCENARIO 6: Leader Rotation ====================
describe('Scenario 6: Leader rotation', () => {
  test('Leader rotates through all players', () => {
    const playerCount = 5;
    let currentLeader = 0;
    
    // Simulate 6 rounds (more than player count)
    for (let i = 0; i < 6; i++) {
      currentLeader = getNextLeaderIndex(currentLeader, playerCount);
    }
    
    // After 6 rotations from 0, should be at position 1
    expect(currentLeader).toBe(1);
  });
});

// ==================== SCENARIO 7: Voting Flow ====================
describe('Scenario 7: Voting scenarios', () => {
  test('Team approved 4-1', () => {
    expect(determineVoteResult(4, 1)).toBe('approved');
  });
  
  test('Team rejected 2-3', () => {
    expect(determineVoteResult(2, 3)).toBe('rejected');
  });
  
  test('Tie 3-3 - rejected', () => {
    expect(determineVoteResult(3, 3)).toBe('rejected');
  });
  
  test('Unanimous approval 5-0', () => {
    expect(determineVoteResult(5, 0)).toBe('approved');
  });
});

// ==================== SCENARIO 8: Merlin Knowledge ====================
describe('Scenario 8: Merlin special knowledge', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'loyal', 'loyal'];
  
  test('Merlin does not know Mordred', () => {
    const assignments = assignRoles(playerIds, selectedRoles);
    
    const merlinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'merlin');
    const mordredEntry = Object.entries(assignments).find(([_, a]) => a.role === 'mordred');
    
    expect(merlinEntry).toBeDefined();
    expect(mordredEntry).toBeDefined();
    
    // Merlin should NOT know Mordred
    expect(merlinEntry![1].knownPlayers).not.toContain(mordredEntry![0]);
  });
  
  test('Merlin knows other Evil players', () => {
    const assignments = assignRoles(playerIds, selectedRoles);
    
    const merlinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'merlin');
    const assassinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'assassin');
    const morganaEntry = Object.entries(assignments).find(([_, a]) => a.role === 'morgana');
    
    expect(merlinEntry).toBeDefined();
    
    // Merlin should know Assassin and Morgana
    if (assassinEntry) {
      expect(merlinEntry![1].knownPlayers).toContain(assassinEntry[0]);
    }
    if (morganaEntry) {
      expect(merlinEntry![1].knownPlayers).toContain(morganaEntry[0]);
    }
  });
});

// ==================== SCENARIO 9: Oberon Isolation ====================
describe('Scenario 9: Oberon is isolated', () => {
  // Run multiple times to account for randomness
  for (let i = 0; i < 10; i++) {
    const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];
    const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'oberon', 'loyal', 'loyal'];
    const assignments = assignRoles(playerIds, selectedRoles);
    
    const oberonEntry = Object.entries(assignments).find(([_, a]) => a.role === 'oberon');
    
    if (oberonEntry) {
      test(`Oberon knows no one (attempt ${i + 1})`, () => {
        expect(oberonEntry[1].knownPlayers.length).toBe(0);
      });
      
      test(`Other Evil players do not know Oberon (attempt ${i + 1})`, () => {
        const assassinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'assassin');
        if (assassinEntry) {
          expect(assassinEntry[1].knownPlayers).not.toContain(oberonEntry[0]);
        }
      });
      break; // Found Oberon, no need to continue
    }
  }
});

// ==================== SCENARIO 10: Percival Confusion ====================
describe('Scenario 10: Percival sees Merlin and Morgana', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  
  test('Percival sees both Merlin and Morgana', () => {
    const assignments = assignRoles(playerIds, selectedRoles);
    
    const percivalEntry = Object.entries(assignments).find(([_, a]) => a.role === 'percival');
    const merlinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'merlin');
    const morganaEntry = Object.entries(assignments).find(([_, a]) => a.role === 'morgana');
    
    expect(percivalEntry).toBeDefined();
    expect(merlinEntry).toBeDefined();
    expect(morganaEntry).toBeDefined();
    
    // Percival should see both
    expect(percivalEntry![1].knownPlayers).toContain(merlinEntry![0]);
    expect(percivalEntry![1].knownPlayers).toContain(morganaEntry![0]);
    
    // Percival should see exactly 2 people
    expect(percivalEntry![1].knownPlayers.length).toBe(2);
  });
});

// ==================== SUMMARY ====================
console.log('\n' + '='.repeat(50));
console.log(`📊 Game Flow Test Results: ${passed} passed, ${failed} failed`);
console.log('='.repeat(50) + '\n');

if (failed === 0) {
  console.log('🎉 All game flow tests passed!');
} else {
  console.log('⚠️ Some tests failed. Please review.');
}

process.exit(failed > 0 ? 1 : 0);

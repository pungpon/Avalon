import { describe, it, expect } from 'vitest';
import { 
  assignRoles, 
  getTeamSize, 
  determineQuestResult,
  checkWinner,
  determineVoteResult,
  checkEvilWinsByRejections,
  getNextLeaderIndex,
  requiresTwoFails,
  getDefaultRoles
} from '@/lib/gameLogic';
import { ROLE_DISTRIBUTION, ROLE_DEFINITIONS, TEAM_SIZES } from '@/types';
import type { Role } from '@/types';

describe('Game Logic Tests', () => {
  
  describe('Role Distribution', () => {
    it('should have correct role distribution for all player counts', () => {
      expect(ROLE_DISTRIBUTION[5]).toEqual({ good: 3, evil: 2 });
      expect(ROLE_DISTRIBUTION[6]).toEqual({ good: 4, evil: 2 });
      expect(ROLE_DISTRIBUTION[7]).toEqual({ good: 4, evil: 3 });
      expect(ROLE_DISTRIBUTION[8]).toEqual({ good: 5, evil: 3 });
      expect(ROLE_DISTRIBUTION[9]).toEqual({ good: 6, evil: 4 });
      expect(ROLE_DISTRIBUTION[10]).toEqual({ good: 6, evil: 4 });
    });
  });

  describe('Team Sizes', () => {
    it('should return correct team sizes for 5 players', () => {
      expect(TEAM_SIZES[5]).toEqual([2, 3, 2, 3, 3]);
    });

    it('should return correct team sizes for 7 players', () => {
      expect(TEAM_SIZES[7]).toEqual([2, 3, 3, 4, 4]);
    });

    it('should return correct team sizes for 10 players', () => {
      expect(TEAM_SIZES[10]).toEqual([3, 4, 4, 5, 5]);
    });
  });

  describe('getTeamSize', () => {
    it('should return correct team size for given player count and round', () => {
      expect(getTeamSize(5, 0)).toBe(2);
      expect(getTeamSize(5, 2)).toBe(2);
      expect(getTeamSize(7, 3)).toBe(4);
      expect(getTeamSize(10, 4)).toBe(5);
    });

    it('should return 0 for invalid player count', () => {
      expect(getTeamSize(4, 0)).toBe(0);
      expect(getTeamSize(11, 0)).toBe(0);
    });
  });

  describe('requiresTwoFails', () => {
    it('should return true for quest 4 with 7+ players', () => {
      expect(requiresTwoFails(7, 3)).toBe(true);
      expect(requiresTwoFails(8, 3)).toBe(true);
      expect(requiresTwoFails(9, 3)).toBe(true);
      expect(requiresTwoFails(10, 3)).toBe(true);
    });

    it('should return false for quest 4 with 5-6 players', () => {
      expect(requiresTwoFails(5, 3)).toBe(false);
      expect(requiresTwoFails(6, 3)).toBe(false);
    });

    it('should return false for other quests', () => {
      expect(requiresTwoFails(7, 0)).toBe(false);
      expect(requiresTwoFails(7, 1)).toBe(false);
      expect(requiresTwoFails(7, 2)).toBe(false);
      expect(requiresTwoFails(7, 4)).toBe(false);
    });
  });

  describe('assignRoles', () => {
    it('should assign correct number of roles for 5 players', () => {
      const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
      const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
      
      const assignments = assignRoles(playerIds, selectedRoles);
      
      expect(Object.keys(assignments).length).toBe(5);
      
      const goodCount = Object.values(assignments).filter(a => a.team === 'good').length;
      const evilCount = Object.values(assignments).filter(a => a.team === 'evil').length;
      
      expect(goodCount).toBe(3);
      expect(evilCount).toBe(2);
    });

    it('should assign correct number of roles for 7 players', () => {
      const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7'];
      const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'loyal', 'loyal'];
      
      const assignments = assignRoles(playerIds, selectedRoles);
      
      const goodCount = Object.values(assignments).filter(a => a.team === 'good').length;
      const evilCount = Object.values(assignments).filter(a => a.team === 'evil').length;
      
      expect(goodCount).toBe(4);
      expect(evilCount).toBe(3);
    });

    it('should always include exactly one Merlin', () => {
      const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
      const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
      
      const assignments = assignRoles(playerIds, selectedRoles);
      
      const merlinCount = Object.values(assignments).filter(a => a.role === 'merlin').length;
      expect(merlinCount).toBe(1);
    });

    it('should make Merlin know all Evil except Mordred', () => {
      const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7'];
      const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'loyal', 'loyal'];
      
      const assignments = assignRoles(playerIds, selectedRoles);
      
      const merlinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'merlin');
      const mordredEntry = Object.entries(assignments).find(([_, a]) => a.role === 'mordred');
      
      expect(merlinEntry).toBeDefined();
      expect(mordredEntry).toBeDefined();
      
      // Merlin should NOT know Mordred
      expect(merlinEntry![1].knownPlayers).not.toContain(mordredEntry![0]);
    });

    it('should make Evil players know each other except Oberon', () => {
      const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];
      const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'oberon', 'loyal', 'loyal'];
      
      const assignments = assignRoles(playerIds, selectedRoles);
      
      const oberonEntry = Object.entries(assignments).find(([_, a]) => a.role === 'oberon');
      const assassinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'assassin');
      
      expect(oberonEntry).toBeDefined();
      expect(assassinEntry).toBeDefined();
      
      // Oberon should not know anyone
      expect(oberonEntry![1].knownPlayers.length).toBe(0);
      
      // Assassin should not know Oberon
      expect(assassinEntry![1].knownPlayers).not.toContain(oberonEntry![0]);
    });

    it('should make Percival see Merlin and Morgana', () => {
      const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
      const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
      
      const assignments = assignRoles(playerIds, selectedRoles);
      
      const percivalEntry = Object.entries(assignments).find(([_, a]) => a.role === 'percival');
      const merlinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'merlin');
      const morganaEntry = Object.entries(assignments).find(([_, a]) => a.role === 'morgana');
      
      expect(percivalEntry).toBeDefined();
      expect(merlinEntry).toBeDefined();
      expect(morganaEntry).toBeDefined();
      
      // Percival should see both Merlin and Morgana
      expect(percivalEntry![1].knownPlayers).toContain(merlinEntry![0]);
      expect(percivalEntry![1].knownPlayers).toContain(morganaEntry![0]);
    });
  });

  describe('determineQuestResult', () => {
    it('should succeed with all success cards', () => {
      const cards = { p1: 'success' as const, p2: 'success' as const, p3: 'success' as const };
      expect(determineQuestResult(5, 0, cards)).toBe('success');
    });

    it('should fail with one fail card (normal quest)', () => {
      const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'success' as const };
      expect(determineQuestResult(5, 0, cards)).toBe('fail');
    });

    it('should succeed with one fail card (quest 4 with 7+ players)', () => {
      const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'success' as const, p4: 'success' as const };
      expect(determineQuestResult(7, 3, cards)).toBe('success');
    });

    it('should fail with two fail cards (quest 4 with 7+ players)', () => {
      const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'fail' as const, p4: 'success' as const };
      expect(determineQuestResult(7, 3, cards)).toBe('fail');
    });

    it('should count fail cards correctly', () => {
      const cards = { p1: 'fail' as const, p2: 'fail' as const, p3: 'success' as const };
      expect(determineQuestResult(5, 0, cards)).toBe('fail');
    });
  });

  describe('checkWinner', () => {
    it('should return good when good wins 3 quests', () => {
      const results: ('success' | 'fail' | null)[] = ['success', 'success', 'success', null, null];
      expect(checkWinner(results)).toBe('good');
    });

    it('should return evil when evil wins 3 quests', () => {
      const results: ('success' | 'fail' | null)[] = ['fail', 'fail', 'fail', null, null];
      expect(checkWinner(results)).toBe('evil');
    });

    it('should return null when no winner yet', () => {
      const results: ('success' | 'fail' | null)[] = ['success', 'fail', 'success', null, null];
      expect(checkWinner(results)).toBeNull();
    });

    it('should return good when good wins 3-2', () => {
      const results: ('success' | 'fail' | null)[] = ['success', 'fail', 'success', 'fail', 'success'];
      expect(checkWinner(results)).toBe('good');
    });

    it('should return evil when evil wins 3-2', () => {
      const results: ('success' | 'fail' | null)[] = ['fail', 'success', 'fail', 'success', 'fail'];
      expect(checkWinner(results)).toBe('evil');
    });

    it('should return null with empty results', () => {
      const results: (null)[] = [null, null, null, null, null];
      expect(checkWinner(results)).toBeNull();
    });
  });

  describe('determineVoteResult', () => {
    it('should approve with majority approve', () => {
      expect(determineVoteResult(3, 2)).toBe('approved');
      expect(determineVoteResult(4, 1)).toBe('approved');
    });

    it('should reject with majority reject', () => {
      expect(determineVoteResult(2, 3)).toBe('rejected');
      expect(determineVoteResult(1, 4)).toBe('rejected');
    });

    it('should reject with tie', () => {
      expect(determineVoteResult(2, 2)).toBe('rejected');
      expect(determineVoteResult(3, 3)).toBe('rejected');
    });

    it('should approve with unanimous approval', () => {
      expect(determineVoteResult(5, 0)).toBe('approved');
    });

    it('should reject with unanimous rejection', () => {
      expect(determineVoteResult(0, 5)).toBe('rejected');
    });
  });

  describe('checkEvilWinsByRejections', () => {
    it('should return true at 5 rejections', () => {
      expect(checkEvilWinsByRejections(5)).toBe(true);
      expect(checkEvilWinsByRejections(6)).toBe(true);
    });

    it('should return false below 5 rejections', () => {
      expect(checkEvilWinsByRejections(4)).toBe(false);
      expect(checkEvilWinsByRejections(3)).toBe(false);
      expect(checkEvilWinsByRejections(0)).toBe(false);
    });
  });

  describe('getNextLeaderIndex', () => {
    it('should rotate to next leader', () => {
      expect(getNextLeaderIndex(0, 5)).toBe(1);
      expect(getNextLeaderIndex(1, 5)).toBe(2);
      expect(getNextLeaderIndex(2, 5)).toBe(3);
      expect(getNextLeaderIndex(3, 5)).toBe(4);
    });

    it('should wrap around correctly', () => {
      expect(getNextLeaderIndex(4, 5)).toBe(0);
      expect(getNextLeaderIndex(6, 7)).toBe(0);
      expect(getNextLeaderIndex(9, 10)).toBe(0);
    });
  });

  describe('getDefaultRoles', () => {
    it('should return correct roles for 5 players', () => {
      const roles = getDefaultRoles(5);
      expect(roles).toContain('merlin');
      expect(roles).toContain('assassin');
      expect(roles).toContain('percival');
      expect(roles).toContain('morgana');
    });

    it('should return correct roles for 7 players', () => {
      const roles = getDefaultRoles(7);
      expect(roles).toContain('merlin');
      expect(roles).toContain('assassin');
      expect(roles).toContain('percival');
      expect(roles).toContain('morgana');
      expect(roles).toContain('mordred');
    });

    it('should return correct roles for 8+ players', () => {
      const roles = getDefaultRoles(8);
      expect(roles).toContain('merlin');
      expect(roles).toContain('assassin');
      expect(roles).toContain('percival');
      expect(roles).toContain('morgana');
      expect(roles).toContain('mordred');
      expect(roles).toContain('oberon');
    });
  });

  describe('ROLE_DEFINITIONS', () => {
    it('should have all required roles defined', () => {
      const requiredRoles: Role[] = ['merlin', 'percival', 'loyal', 'assassin', 'morgana', 'mordred', 'oberon', 'minion', 'tristan', 'isolde'];
      requiredRoles.forEach(role => {
        expect(ROLE_DEFINITIONS[role]).toBeDefined();
      });
    });

    it('should have correct team assignments', () => {
      expect(ROLE_DEFINITIONS.merlin.team).toBe('good');
      expect(ROLE_DEFINITIONS.percival.team).toBe('good');
      expect(ROLE_DEFINITIONS.loyal.team).toBe('good');
      expect(ROLE_DEFINITIONS.assassin.team).toBe('evil');
      expect(ROLE_DEFINITIONS.morgana.team).toBe('evil');
      expect(ROLE_DEFINITIONS.mordred.team).toBe('evil');
      expect(ROLE_DEFINITIONS.oberon.team).toBe('evil');
      expect(ROLE_DEFINITIONS.minion.team).toBe('evil');
    });

    it('should have Thai names for all roles', () => {
      Object.values(ROLE_DEFINITIONS).forEach(role => {
        expect(role.nameTh).toBeDefined();
        expect(role.nameTh.length).toBeGreaterThan(0);
      });
    });

    it('should have descriptions for all roles', () => {
      Object.values(ROLE_DEFINITIONS).forEach(role => {
        expect(role.descriptionTh).toBeDefined();
        expect(role.descriptionTh.length).toBeGreaterThan(0);
      });
    });
  });
});

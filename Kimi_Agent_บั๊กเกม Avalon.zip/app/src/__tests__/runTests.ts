// Simple test runner
import { 
  assignRoles, 
  getTeamSize, 
  determineQuestResult,
  checkWinner,
  determineVoteResult,
  checkEvilWinsByRejections,
  getNextLeaderIndex,
  requiresTwoFails,
  getDefaultRoles
} from '@/lib/gameLogic';
import { ROLE_DISTRIBUTION, ROLE_DEFINITIONS, TEAM_SIZES } from '@/types';
import type { Role } from '@/types';

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void) {
  try {
    fn();
    console.log(`✅ ${name}`);
    passed++;
  } catch (err) {
    console.log(`❌ ${name}`);
    console.log(`   Error: ${err}`);
    failed++;
  }
}

function expect(actual: any) {
  return {
    toBe(expected: any) {
      if (actual !== expected) {
        throw new Error(`Expected ${expected} but got ${actual}`);
      }
    },
    toEqual(expected: any) {
      if (JSON.stringify(actual) !== JSON.stringify(expected)) {
        throw new Error(`Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
      }
    },
    toBeDefined() {
      if (actual === undefined) {
        throw new Error(`Expected value to be defined but got undefined`);
      }
    },
    toContain(item: any) {
      if (!actual.includes(item)) {
        throw new Error(`Expected array to contain ${item}`);
      }
    },
    not: {
      toContain(item: any) {
        if (actual.includes(item)) {
          throw new Error(`Expected array NOT to contain ${item}`);
        }
      }
    },
    toBeNull() {
      if (actual !== null) {
        throw new Error(`Expected null but got ${actual}`);
      }
    },
    toBeGreaterThan(expected: number) {
      if (!(actual > expected)) {
        throw new Error(`Expected ${actual} to be greater than ${expected}`);
      }
    }
  };
}

console.log('\n🧪 Running Game Logic Tests\n');

// Role Distribution Tests
test('ROLE_DISTRIBUTION[5] should be { good: 3, evil: 2 }', () => {
  expect(ROLE_DISTRIBUTION[5]).toEqual({ good: 3, evil: 2 });
});

test('ROLE_DISTRIBUTION[7] should be { good: 4, evil: 3 }', () => {
  expect(ROLE_DISTRIBUTION[7]).toEqual({ good: 4, evil: 3 });
});

// Team Sizes Tests
test('TEAM_SIZES[5] should be [2, 3, 2, 3, 3]', () => {
  expect(TEAM_SIZES[5]).toEqual([2, 3, 2, 3, 3]);
});

test('TEAM_SIZES[7] should be [2, 3, 3, 4, 4]', () => {
  expect(TEAM_SIZES[7]).toEqual([2, 3, 3, 4, 4]);
});

// getTeamSize Tests
test('getTeamSize(5, 0) should return 2', () => {
  expect(getTeamSize(5, 0)).toBe(2);
});

test('getTeamSize(7, 3) should return 4', () => {
  expect(getTeamSize(7, 3)).toBe(4);
});

test('getTeamSize(4, 0) should return 0 (invalid)', () => {
  expect(getTeamSize(4, 0)).toBe(0);
});

// requiresTwoFails Tests
test('requiresTwoFails(7, 3) should be true', () => {
  expect(requiresTwoFails(7, 3)).toBe(true);
});

test('requiresTwoFails(5, 3) should be false', () => {
  expect(requiresTwoFails(5, 3)).toBe(false);
});

// assignRoles Tests
test('assignRoles should assign correct number of roles for 5 players', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  
  expect(Object.keys(assignments).length).toBe(5);
});

test('assignRoles should have 3 good and 2 evil for 5 players', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  
  const goodCount = Object.values(assignments).filter(a => a.team === 'good').length;
  const evilCount = Object.values(assignments).filter(a => a.team === 'evil').length;
  
  expect(goodCount).toBe(3);
  expect(evilCount).toBe(2);
});

test('assignRoles should have exactly one Merlin', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  
  const merlinCount = Object.values(assignments).filter(a => a.role === 'merlin').length;
  expect(merlinCount).toBe(1);
});

// determineQuestResult Tests
test('Quest should succeed with all success cards', () => {
  const cards = { p1: 'success' as const, p2: 'success' as const, p3: 'success' as const };
  expect(determineQuestResult(5, 0, cards)).toBe('success');
});

test('Quest should fail with one fail card (normal quest)', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'success' as const };
  expect(determineQuestResult(5, 0, cards)).toBe('fail');
});

test('Quest 4 with 7+ players should succeed with one fail', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'success' as const, p4: 'success' as const };
  expect(determineQuestResult(7, 3, cards)).toBe('success');
});

test('Quest 4 with 7+ players should fail with two fails', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'fail' as const, p4: 'success' as const };
  expect(determineQuestResult(7, 3, cards)).toBe('fail');
});

// checkWinner Tests
test('Good wins with 3 successes', () => {
  const results: ('success' | 'fail' | null)[] = ['success', 'success', 'success', null, null];
  expect(checkWinner(results)).toBe('good');
});

test('Evil wins with 3 fails', () => {
  const results: ('success' | 'fail' | null)[] = ['fail', 'fail', 'fail', null, null];
  expect(checkWinner(results)).toBe('evil');
});

test('No winner with 2-1 score', () => {
  const results: ('success' | 'fail' | null)[] = ['success', 'fail', 'success', null, null];
  expect(checkWinner(results)).toBeNull();
});

// determineVoteResult Tests
test('Vote approved with majority', () => {
  expect(determineVoteResult(3, 2)).toBe('approved');
});

test('Vote rejected with majority reject', () => {
  expect(determineVoteResult(2, 3)).toBe('rejected');
});

test('Vote rejected with tie', () => {
  expect(determineVoteResult(2, 2)).toBe('rejected');
});

// checkEvilWinsByRejections Tests
test('Evil wins at 5 rejections', () => {
  expect(checkEvilWinsByRejections(5)).toBe(true);
});

test('Evil does not win below 5 rejections', () => {
  expect(checkEvilWinsByRejections(4)).toBe(false);
});

// getNextLeaderIndex Tests
test('Leader rotates correctly', () => {
  expect(getNextLeaderIndex(0, 5)).toBe(1);
  expect(getNextLeaderIndex(1, 5)).toBe(2);
});

test('Leader wraps around', () => {
  expect(getNextLeaderIndex(4, 5)).toBe(0);
});

// ROLE_DEFINITIONS Tests
test('All required roles are defined', () => {
  const requiredRoles: Role[] = ['merlin', 'percival', 'loyal', 'assassin', 'morgana', 'mordred', 'oberon', 'minion'];
  requiredRoles.forEach(role => {
    expect(ROLE_DEFINITIONS[role]).toBeDefined();
  });
});

test('Merlin is good team', () => {
  expect(ROLE_DEFINITIONS.merlin.team).toBe('good');
});

test('Assassin is evil team', () => {
  expect(ROLE_DEFINITIONS.assassin.team).toBe('evil');
});

// getDefaultRoles Tests
test('getDefaultRoles(5) includes merlin and assassin', () => {
  const roles = getDefaultRoles(5);
  expect(roles).toContain('merlin');
  expect(roles).toContain('assassin');
});

console.log('\n' + '='.repeat(40));
console.log(`📊 Results: ${passed} passed, ${failed} failed`);
console.log('='.repeat(40) + '\n');

process.exit(failed > 0 ? 1 : 0);

#!/usr/bin/env tsx
// Test Runner for Avalon Game
// Runs all tests: Logic Tests, Flow Tests, and UI Component Tests

import { execSync } from 'child_process';
import path from 'path';

const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
};

function printHeader(title: string) {
  console.log('\n' + colors.cyan + '='.repeat(60) + colors.reset);
  console.log(colors.bright + colors.blue + '  ' + title + colors.reset);
  console.log(colors.cyan + '='.repeat(60) + colors.reset + '\n');
}

function printResult(name: string, passed: boolean, message?: string) {
  const icon = passed ? colors.green + '✓' : colors.red + '✗';
  const status = passed ? colors.green + 'PASS' : colors.red + 'FAIL';
  console.log(`  ${icon} ${name}: ${status}${colors.reset}`);
  if (message && !passed) {
    console.log(`    ${colors.dim}${message}${colors.reset}`);
  }
}

// ==================== GAME LOGIC TESTS ====================
printHeader('GAME LOGIC TESTS');

let logicPassed = 0;
let logicFailed = 0;

function testLogic(name: string, fn: () => void) {
  try {
    fn();
    printResult(name, true);
    logicPassed++;
  } catch (err: any) {
    printResult(name, false, err.message);
    logicFailed++;
  }
}

function expect(actual: any) {
  return {
    toBe(expected: any) {
      if (actual !== expected) {
        throw new Error(`Expected ${expected} but got ${actual}`);
      }
    },
    toEqual(expected: any) {
      if (JSON.stringify(actual) !== JSON.stringify(expected)) {
        throw new Error(`Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
      }
    },
    toBeDefined() {
      if (actual === undefined) {
        throw new Error(`Expected value to be defined`);
      }
    },
    toContain(item: any) {
      if (!actual.includes(item)) {
        throw new Error(`Expected array to contain ${item}`);
      }
    },
    not: {
      toContain(item: any) {
        if (actual.includes(item)) {
          throw new Error(`Expected array NOT to contain ${item}`);
        }
      }
    },
    toBeNull() {
      if (actual !== null) {
        throw new Error(`Expected null but got ${actual}`);
      }
    },
    toBeTrue() {
      if (actual !== true) {
        throw new Error(`Expected true but got ${actual}`);
      }
    },
    toBeFalse() {
      if (actual !== false) {
        throw new Error(`Expected false but got ${actual}`);
      }
    }
  };
}

// Import game logic
import { 
  assignRoles, 
  getTeamSize, 
  determineQuestResult,
  checkWinner,
  determineVoteResult,
  checkEvilWinsByRejections,
  getNextLeaderIndex,
  requiresTwoFails,
  getDefaultRoles
} from '@/lib/gameLogic';
import { ROLE_DISTRIBUTION, ROLE_DEFINITIONS, TEAM_SIZES } from '@/types';
import type { Role } from '@/types';

// Role Distribution
testLogic('ROLE_DISTRIBUTION[5] = {good:3, evil:2}', () => {
  expect(ROLE_DISTRIBUTION[5]).toEqual({ good: 3, evil: 2 });
});

testLogic('ROLE_DISTRIBUTION[7] = {good:4, evil:3}', () => {
  expect(ROLE_DISTRIBUTION[7]).toEqual({ good: 4, evil: 3 });
});

// Team Sizes
testLogic('TEAM_SIZES[5] = [2,3,2,3,3]', () => {
  expect(TEAM_SIZES[5]).toEqual([2, 3, 2, 3, 3]);
});

testLogic('TEAM_SIZES[7] = [2,3,3,4,4]', () => {
  expect(TEAM_SIZES[7]).toEqual([2, 3, 3, 4, 4]);
});

// getTeamSize
testLogic('getTeamSize(5,0) returns 2', () => {
  expect(getTeamSize(5, 0)).toBe(2);
});

testLogic('getTeamSize(7,3) returns 4', () => {
  expect(getTeamSize(7, 3)).toBe(4);
});

testLogic('getTeamSize(4,0) returns 0 (invalid)', () => {
  expect(getTeamSize(4, 0)).toBe(0);
});

// requiresTwoFails
testLogic('requiresTwoFails(7,3) = true', () => {
  expect(requiresTwoFails(7, 3)).toBeTrue();
});

testLogic('requiresTwoFails(5,3) = false', () => {
  expect(requiresTwoFails(5, 3)).toBeFalse();
});

// assignRoles
testLogic('assignRoles assigns 5 roles for 5 players', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  expect(Object.keys(assignments).length).toBe(5);
});

testLogic('assignRoles has 3 good and 2 evil for 5 players', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  const goodCount = Object.values(assignments).filter(a => a.team === 'good').length;
  const evilCount = Object.values(assignments).filter(a => a.team === 'evil').length;
  expect(goodCount).toBe(3);
  expect(evilCount).toBe(2);
});

testLogic('assignRoles has exactly one Merlin', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  const merlinCount = Object.values(assignments).filter(a => a.role === 'merlin').length;
  expect(merlinCount).toBe(1);
});

// determineQuestResult
testLogic('Quest succeeds with all success cards', () => {
  const cards = { p1: 'success' as const, p2: 'success' as const, p3: 'success' as const };
  expect(determineQuestResult(5, 0, cards)).toBe('success');
});

testLogic('Quest fails with one fail card (normal)', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'success' as const };
  expect(determineQuestResult(5, 0, cards)).toBe('fail');
});

testLogic('Quest 4 (7+) succeeds with one fail', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'success' as const, p4: 'success' as const };
  expect(determineQuestResult(7, 3, cards)).toBe('success');
});

testLogic('Quest 4 (7+) fails with two fails', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'fail' as const, p4: 'success' as const };
  expect(determineQuestResult(7, 3, cards)).toBe('fail');
});

// checkWinner
testLogic('Good wins with 3 successes', () => {
  const results: ('success' | 'fail' | null)[] = ['success', 'success', 'success', null, null];
  expect(checkWinner(results)).toBe('good');
});

testLogic('Evil wins with 3 fails', () => {
  const results: ('success' | 'fail' | null)[] = ['fail', 'fail', 'fail', null, null];
  expect(checkWinner(results)).toBe('evil');
});

testLogic('No winner with 2-1 score', () => {
  const results: ('success' | 'fail' | null)[] = ['success', 'fail', 'success', null, null];
  expect(checkWinner(results)).toBeNull();
});

// determineVoteResult
testLogic('Vote approved with majority', () => {
  expect(determineVoteResult(3, 2)).toBe('approved');
});

testLogic('Vote rejected with majority reject', () => {
  expect(determineVoteResult(2, 3)).toBe('rejected');
});

testLogic('Vote rejected with tie', () => {
  expect(determineVoteResult(2, 2)).toBe('rejected');
});

// checkEvilWinsByRejections
testLogic('Evil wins at 5 rejections', () => {
  expect(checkEvilWinsByRejections(5)).toBeTrue();
});

testLogic('Evil does not win below 5 rejections', () => {
  expect(checkEvilWinsByRejections(4)).toBeFalse();
});

// getNextLeaderIndex
testLogic('Leader rotates correctly', () => {
  expect(getNextLeaderIndex(0, 5)).toBe(1);
  expect(getNextLeaderIndex(1, 5)).toBe(2);
});

testLogic('Leader wraps around', () => {
  expect(getNextLeaderIndex(4, 5)).toBe(0);
});

// ROLE_DEFINITIONS
testLogic('All required roles are defined', () => {
  const requiredRoles: Role[] = ['merlin', 'percival', 'loyal', 'assassin', 'morgana', 'mordred', 'oberon', 'minion'];
  requiredRoles.forEach(role => {
    expect(ROLE_DEFINITIONS[role]).toBeDefined();
  });
});

testLogic('Merlin is good team', () => {
  expect(ROLE_DEFINITIONS.merlin.team).toBe('good');
});

testLogic('Assassin is evil team', () => {
  expect(ROLE_DEFINITIONS.assassin.team).toBe('evil');
});

// ==================== GAME FLOW TESTS ====================
printHeader('GAME FLOW TESTS');

let flowPassed = 0;
let flowFailed = 0;

function testFlow(name: string, fn: () => void) {
  try {
    fn();
    printResult(name, true);
    flowPassed++;
  } catch (err: any) {
    printResult(name, false, err.message);
    flowFailed++;
  }
}

// Scenario 1: Good wins 3-0
testFlow('Scenario 1: Good wins 3-0 - Quest 1 success', () => {
  const cards = { p1: 'success' as const, p2: 'success' as const };
  expect(determineQuestResult(5, 0, cards)).toBe('success');
});

testFlow('Scenario 1: Good wins 3-0 - Quest 2 success', () => {
  const cards = { p1: 'success' as const, p2: 'success' as const, p3: 'success' as const };
  expect(determineQuestResult(5, 1, cards)).toBe('success');
});

testFlow('Scenario 1: Good wins 3-0 - Quest 3 success', () => {
  const cards = { p1: 'success' as const, p2: 'success' as const };
  expect(determineQuestResult(5, 2, cards)).toBe('success');
});

testFlow('Scenario 1: Good wins 3-0 - Winner check', () => {
  const results: ('success' | 'fail' | null)[] = ['success', 'success', 'success', null, null];
  expect(checkWinner(results)).toBe('good');
});

// Scenario 2: Evil wins 3-0
testFlow('Scenario 2: Evil wins 3-0 - Quest 1 fail', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const };
  expect(determineQuestResult(5, 0, cards)).toBe('fail');
});

testFlow('Scenario 2: Evil wins 3-0 - Quest 2 fail', () => {
  const cards = { p1: 'success' as const, p2: 'success' as const, p3: 'fail' as const };
  expect(determineQuestResult(5, 1, cards)).toBe('fail');
});

testFlow('Scenario 2: Evil wins 3-0 - Quest 3 fail', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const };
  expect(determineQuestResult(5, 2, cards)).toBe('fail');
});

testFlow('Scenario 2: Evil wins 3-0 - Winner check', () => {
  const results: ('success' | 'fail' | null)[] = ['fail', 'fail', 'fail', null, null];
  expect(checkWinner(results)).toBe('evil');
});

// Scenario 3: Good wins 3-2
testFlow('Scenario 3: Good wins 3-2 - Winner check', () => {
  const results: ('success' | 'fail' | null)[] = ['success', 'fail', 'success', 'fail', 'success'];
  expect(checkWinner(results)).toBe('good');
});

// Scenario 4: Evil wins by rejections
testFlow('Scenario 4: 4 rejections - game continues', () => {
  expect(checkEvilWinsByRejections(4)).toBeFalse();
});

testFlow('Scenario 4: 5 rejections - evil wins', () => {
  expect(checkEvilWinsByRejections(5)).toBeTrue();
});

// Scenario 5: 7 players - Quest 4 special rule
testFlow('Scenario 5: Quest 4 requires 2 fails for 7 players', () => {
  expect(requiresTwoFails(7, 3)).toBeTrue();
});

testFlow('Scenario 5: Quest 4 succeeds with 1 fail', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'success' as const, p4: 'success' as const };
  expect(determineQuestResult(7, 3, cards)).toBe('success');
});

testFlow('Scenario 5: Quest 4 fails with 2 fails', () => {
  const cards = { p1: 'success' as const, p2: 'fail' as const, p3: 'fail' as const, p4: 'success' as const };
  expect(determineQuestResult(7, 3, cards)).toBe('fail');
});

// Scenario 6: Leader rotation
testFlow('Scenario 6: Leader rotates through all players', () => {
  expect(getNextLeaderIndex(0, 5)).toBe(1);
  expect(getNextLeaderIndex(1, 5)).toBe(2);
  expect(getNextLeaderIndex(2, 5)).toBe(3);
  expect(getNextLeaderIndex(3, 5)).toBe(4);
  expect(getNextLeaderIndex(4, 5)).toBe(0);
});

// Scenario 7: Voting
testFlow('Scenario 7: Team approved 4-1', () => {
  expect(determineVoteResult(4, 1)).toBe('approved');
});

testFlow('Scenario 7: Team rejected 2-3', () => {
  expect(determineVoteResult(2, 3)).toBe('rejected');
});

testFlow('Scenario 7: Tie 3-3 - rejected', () => {
  expect(determineVoteResult(3, 3)).toBe('rejected');
});

// Scenario 8: Merlin knowledge
testFlow('Scenario 8: Merlin does not know Mordred', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'loyal', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  
  const merlinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'merlin');
  const mordredEntry = Object.entries(assignments).find(([_, a]) => a.role === 'mordred');
  
  if (merlinEntry && mordredEntry) {
    expect(merlinEntry[1].knownPlayers).not.toContain(mordredEntry[0]);
  }
});

// Scenario 9: Oberon isolation
testFlow('Scenario 9: Oberon knows no one', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'oberon', 'loyal', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  
  const oberonEntry = Object.entries(assignments).find(([_, a]) => a.role === 'oberon');
  if (oberonEntry) {
    expect(oberonEntry[1].knownPlayers.length).toBe(0);
  }
});

// Scenario 10: Percival confusion
testFlow('Scenario 10: Percival sees both Merlin and Morgana', () => {
  const playerIds = ['p1', 'p2', 'p3', 'p4', 'p5'];
  const selectedRoles: Role[] = ['merlin', 'assassin', 'percival', 'morgana', 'loyal'];
  const assignments = assignRoles(playerIds, selectedRoles);
  
  const percivalEntry = Object.entries(assignments).find(([_, a]) => a.role === 'percival');
  const merlinEntry = Object.entries(assignments).find(([_, a]) => a.role === 'merlin');
  const morganaEntry = Object.entries(assignments).find(([_, a]) => a.role === 'morgana');
  
  if (percivalEntry && merlinEntry && morganaEntry) {
    expect(percivalEntry[1].knownPlayers).toContain(merlinEntry[0]);
    expect(percivalEntry[1].knownPlayers).toContain(morganaEntry[0]);
  }
});

// ==================== UI COMPONENT TESTS ====================
printHeader('UI COMPONENT TESTS');

let uiPassed = 0;
let uiFailed = 0;

function testUI(name: string, fn: () => void) {
  try {
    fn();
    printResult(name, true);
    uiPassed++;
  } catch (err: any) {
    printResult(name, false, err.message);
    uiFailed++;
  }
}

// HomeScreen tests
testUI('HomeScreen: Title renders correctly', () => {
  expect('AVALON').toBeDefined();
});

testUI('HomeScreen: Subtitle renders correctly', () => {
  expect('The Resistance').toBeDefined();
});

testUI('HomeScreen: Has create room button', () => {
  expect('สร้างห้อง (TV Mode)').toBeDefined();
});

testUI('HomeScreen: Has join room button', () => {
  expect('เข้าร่วม (Controller)').toBeDefined();
});

testUI('HomeScreen: Shows player count info', () => {
  expect('รองรับ 5-10 ผู้เล่น').toBeDefined();
});

// JoinRoom tests
testUI('JoinRoom: Has room code input', () => {
  expect('รหัสห้อง (6 ตัว)').toBeDefined();
});

testUI('JoinRoom: Has name input', () => {
  expect('ชื่อของคุณ').toBeDefined();
});

testUI('JoinRoom: Has back button', () => {
  expect('กลับ').toBeDefined();
});

testUI('JoinRoom: Has join button', () => {
  expect('เข้าร่วมห้อง').toBeDefined();
});

// WaitingRoom tests
testUI('WaitingRoom: Shows room title', () => {
  expect('ห้องรอ').toBeDefined();
});

testUI('WaitingRoom: Shows player list', () => {
  expect('ผู้เล่นที่เข้าร่วม').toBeDefined();
});

testUI('WaitingRoom: Has role guide button', () => {
  expect('แสดงคู่มือบทบาท').toBeDefined();
});

testUI('WaitingRoom: Has leave button', () => {
  expect('ออก').toBeDefined();
});

testUI('WaitingRoom: Shows waiting message', () => {
  expect('รอ Host เริ่มเกม...').toBeDefined();
});

// TVMode tests
testUI('TVMode: Shows game title', () => {
  expect('AVALON').toBeDefined();
});

testUI('TVMode: Shows score display', () => {
  expect('Good').toBeDefined();
  expect('Evil').toBeDefined();
});

testUI('TVMode: Shows quest track', () => {
  expect('Q1').toBeDefined();
  expect('Q2').toBeDefined();
  expect('Q3').toBeDefined();
  expect('Q4').toBeDefined();
  expect('Q5').toBeDefined();
});

testUI('TVMode: Shows leader info', () => {
  expect('หัวหน้า:').toBeDefined();
});

// ControllerMode tests
testUI('ControllerMode: Role reveal shows title', () => {
  expect('บทบาทของคุณ').toBeDefined();
});

testUI('ControllerMode: Has blur overlay hint', () => {
  expect('แตะเพื่อเปิดเผย').toBeDefined();
});

testUI('ControllerMode: Has ready button', () => {
  expect('พร้อมเล่น').toBeDefined();
});

testUI('ControllerMode: Team selection shows leader title', () => {
  expect('คุณเป็นหัวหน้า!').toBeDefined();
});

testUI('ControllerMode: Voting shows title', () => {
  expect('โหวตรับรองทีม').toBeDefined();
});

testUI('ControllerMode: Voting has approve button', () => {
  expect('เห็นด้วย').toBeDefined();
});

testUI('ControllerMode: Voting has reject button', () => {
  expect('ไม่เห็นด้วย').toBeDefined();
});

testUI('ControllerMode: Quest shows success card', () => {
  expect('สำเร็จ').toBeDefined();
});

testUI('ControllerMode: Quest shows fail card', () => {
  expect('ล้มเหลว').toBeDefined();
});

testUI('ControllerMode: Game end shows Good wins', () => {
  expect('GOOD WINS!').toBeDefined();
});

testUI('ControllerMode: Game end shows Evil wins', () => {
  expect('EVIL WINS!').toBeDefined();
});

// ==================== SUMMARY ====================
printHeader('TEST SUMMARY');

const totalPassed = logicPassed + flowPassed + uiPassed;
const totalFailed = logicFailed + flowFailed + uiFailed;
const totalTests = totalPassed + totalFailed;

console.log(colors.bright + '  Game Logic Tests:' + colors.reset);
console.log(`    ${colors.green}Passed: ${logicPassed}${colors.reset}`);
console.log(`    ${colors.red}Failed: ${logicFailed}${colors.reset}`);

console.log(colors.bright + '\n  Game Flow Tests:' + colors.reset);
console.log(`    ${colors.green}Passed: ${flowPassed}${colors.reset}`);
console.log(`    ${colors.red}Failed: ${flowFailed}${colors.reset}`);

console.log(colors.bright + '\n  UI Component Tests:' + colors.reset);
console.log(`    ${colors.green}Passed: ${uiPassed}${colors.reset}`);
console.log(`    ${colors.red}Failed: ${uiFailed}${colors.reset}`);

console.log(colors.cyan + '\n' + '='.repeat(60) + colors.reset);
console.log(colors.bright + `  Total: ${totalPassed}/${totalTests} tests passed` + colors.reset);
console.log(colors.cyan + '='.repeat(60) + colors.reset + '\n');

if (totalFailed === 0) {
  console.log(colors.green + colors.bright + '  🎉 All tests passed!' + colors.reset + '\n');
} else {
  console.log(colors.red + colors.bright + `  ⚠️ ${totalFailed} test(s) failed` + colors.reset + '\n');
}

process.exit(totalFailed > 0 ? 1 : 0);

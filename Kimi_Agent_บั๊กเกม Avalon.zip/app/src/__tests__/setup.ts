import '@testing-library/jest-dom';
import { vi } from 'vitest';

// Mock matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
});

// Mock localStorage
const localStorageMock = {
  getItem: vi.fn(),
  setItem: vi.fn(),
  removeItem: vi.fn(),
  clear: vi.fn(),
};
Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
});

// Mock window.location
Object.defineProperty(window, 'location', {
  value: {
    search: '',
    origin: 'http://localhost',
    href: 'http://localhost',
  },
  writable: true,
});

// Mock Firebase
vi.mock('@/lib/firebase', () => ({
  db: {},
  createRoom: vi.fn(),
  joinRoom: vi.fn(),
  subscribeToRoom: vi.fn(() => vi.fn()),
  subscribeToPrivateRole: vi.fn(() => vi.fn()),
  updatePublicBoard: vi.fn(),
  submitVote: vi.fn(),
  submitQuestCard: vi.fn(),
  revealVotes: vi.fn(),
  revealQuestCards: vi.fn(),
  assignRoles: vi.fn(),
  addLog: vi.fn(),
  startGame: vi.fn(),
  endGame: vi.fn(),
  resetRoom: vi.fn(),
  generateRoomCode: vi.fn(() => 'ABC123'),
  generatePlayerId: vi.fn(() => 'player_123'),
  updatePlayerOnlineStatus: vi.fn(),
}));

/**
 * @vitest-environment jsdom
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ControllerMode } from '@/components/ControllerMode';
import type { Player, Role } from '@/types';

vi.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  },
  AnimatePresence: ({ children }: any) => <>{children}</>,
}));

describe('ControllerMode Component - Loading States', () => {
  const mockOnSelectTeam = vi.fn();
  const mockOnSubmitVote = vi.fn();
  const mockOnSubmitQuestCard = vi.fn();
  const mockOnSubmitAssassination = vi.fn();
  const mockOnSetReady = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should show loading when no roomId', () => {
    render(
      <ControllerMode
        roomId={null}
        publicBoard={null}
        players={{}}
        currentPlayer={null}
        privateRole={null}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('กำลังเชื่อมต่อ...')).toBeInTheDocument();
  });

  it('should show error when no currentPlayer', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={{ phase: 'lobby' }}
        players={{}}
        currentPlayer={null}
        privateRole={null}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('ไม่พบข้อมูลผู้เล่น')).toBeInTheDocument();
  });
});

describe('ControllerMode Component - Role Reveal Phase', () => {
  const mockOnSelectTeam = vi.fn();
  const mockOnSubmitVote = vi.fn();
  const mockOnSubmitQuestCard = vi.fn();
  const mockOnSubmitAssassination = vi.fn();
  const mockOnSetReady = vi.fn();

  const createPlayer = (id: string, name: string): Player => ({
    id,
    name,
    seatIndex: 0,
    isOnline: true,
    isLeader: false,
    joinedAt: Date.now(),
  });

  const publicBoard = {
    phase: 'role-reveal',
    round: 0,
    currentTeam: [],
    leaderId: 'p1',
    teamSize: 2,
    voteStatus: { total: 5, casted: 0, revealed: false, approveCount: 0, rejectCount: 0 },
    questStatus: { submitted: 0, required: 1, failCount: 0 },
  };

  it('should show role reveal title', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ p1: createPlayer('p1', 'Alice') }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('บทบาทของคุณ')).toBeInTheDocument();
  });

  it('should show blur overlay initially', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ p1: createPlayer('p1', 'Alice') }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('แตะเพื่อเปิดเผย')).toBeInTheDocument();
  });

  it('should show role name when revealed', async () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ p1: createPlayer('p1', 'Alice') }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    const card = screen.getByText('แตะเพื่อเปิดเผย').closest('div')!;
    fireEvent.click(card);
    
    await waitFor(() => {
      expect(screen.getByText('เมอร์ลิน')).toBeInTheDocument();
    });
  });

  it('should show ready button', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ p1: createPlayer('p1', 'Alice') }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('พร้อมเล่น')).toBeInTheDocument();
  });

  it('should call onSetReady when ready button is clicked', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ p1: createPlayer('p1', 'Alice') }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('พร้อมเล่น'));
    
    expect(mockOnSetReady).toHaveBeenCalledTimes(1);
  });

  it('should show known players for Merlin', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ 
          role: 'merlin' as Role, 
          team: 'good', 
          knownPlayers: ['p2'],
          knownRoles: { p2: 'assassin' as Role }
        }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    const card = screen.getByText('แตะเพื่อเปิดเผย').closest('div')!;
    fireEvent.click(card);
    
    expect(screen.getByText('คุณรู้จัก:')).toBeInTheDocument();
  });
});

describe('ControllerMode Component - Team Selection Phase', () => {
  const mockOnSelectTeam = vi.fn();
  const mockOnSubmitVote = vi.fn();
  const mockOnSubmitQuestCard = vi.fn();
  const mockOnSubmitAssassination = vi.fn();
  const mockOnSetReady = vi.fn();

  const createPlayer = (id: string, name: string): Player => ({
    id,
    name,
    seatIndex: 0,
    isOnline: true,
    isLeader: false,
    joinedAt: Date.now(),
  });

  const publicBoard = {
    phase: 'team-selection',
    round: 0,
    currentTeam: [],
    leaderId: 'p1',
    teamSize: 2,
    voteStatus: { total: 5, casted: 0, revealed: false, approveCount: 0, rejectCount: 0 },
    questStatus: { submitted: 0, required: 1, failCount: 0 },
  };

  it('should show leader view when player is leader', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
          p3: createPlayer('p3', 'Charlie'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('คุณเป็นหัวหน้า!')).toBeInTheDocument();
  });

  it('should show waiting view when player is not leader', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p2', 'Bob')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p2"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('รอหัวหน้าเลือกทีม')).toBeInTheDocument();
  });

  it('should allow leader to select team members', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
          p3: createPlayer('p3', 'Charlie'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('Bob'));
    
    expect(screen.getByText('ยืนยันทีม (1/2)')).toBeInTheDocument();
  });

  it('should disable confirm button until team is full', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
          p3: createPlayer('p3', 'Charlie'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    const confirmButton = screen.getByText('ยืนยันทีม (0/2)');
    expect(confirmButton).toBeDisabled();
  });

  it('should call onSelectTeam when confirm button is clicked', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
          p3: createPlayer('p3', 'Charlie'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('Bob'));
    fireEvent.click(screen.getByText('Charlie'));
    fireEvent.click(screen.getByText('ยืนยันทีม (2/2)'));
    
    expect(mockOnSelectTeam).toHaveBeenCalledWith(['p2', 'p3']);
  });
});

describe('ControllerMode Component - Voting Phase', () => {
  const mockOnSelectTeam = vi.fn();
  const mockOnSubmitVote = vi.fn();
  const mockOnSubmitQuestCard = vi.fn();
  const mockOnSubmitAssassination = vi.fn();
  const mockOnSetReady = vi.fn();

  const createPlayer = (id: string, name: string): Player => ({
    id,
    name,
    seatIndex: 0,
    isOnline: true,
    isLeader: false,
    joinedAt: Date.now(),
  });

  const publicBoard = {
    phase: 'voting',
    round: 0,
    currentTeam: ['p1', 'p2'],
    leaderId: 'p1',
    teamSize: 2,
    voteStatus: { total: 5, casted: 0, revealed: false, approveCount: 0, rejectCount: 0 },
    questStatus: { submitted: 0, required: 1, failCount: 0 },
  };

  it('should show voting title', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('โหวตรับรองทีม')).toBeInTheDocument();
  });

  it('should show approve and reject buttons', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('เห็นด้วย')).toBeInTheDocument();
    expect(screen.getByText('ไม่เห็นด้วย')).toBeInTheDocument();
  });

  it('should call onSubmitVote with approve when approve button is clicked', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('เห็นด้วย'));
    
    expect(mockOnSubmitVote).toHaveBeenCalledWith('approve');
  });

  it('should call onSubmitVote with reject when reject button is clicked', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('ไม่เห็นด้วย'));
    
    expect(mockOnSubmitVote).toHaveBeenCalledWith('reject');
  });

  it('should show voted state after voting', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('เห็นด้วย'));
    
    expect(screen.getByText('โหวตแล้ว')).toBeInTheDocument();
    expect(screen.getByText('รอผู้เล่นคนอื่น...')).toBeInTheDocument();
  });
});

describe('ControllerMode Component - Quest Phase', () => {
  const mockOnSelectTeam = vi.fn();
  const mockOnSubmitVote = vi.fn();
  const mockOnSubmitQuestCard = vi.fn();
  const mockOnSubmitAssassination = vi.fn();
  const mockOnSetReady = vi.fn();

  const createPlayer = (id: string, name: string): Player => ({
    id,
    name,
    seatIndex: 0,
    isOnline: true,
    isLeader: false,
    joinedAt: Date.now(),
  });

  const publicBoard = {
    phase: 'quest',
    round: 0,
    currentTeam: ['p1', 'p2'],
    leaderId: 'p1',
    teamSize: 2,
    voteStatus: { total: 5, casted: 5, revealed: true, approveCount: 3, rejectCount: 2 },
    questStatus: { submitted: 0, required: 1, failCount: 0 },
  };

  it('should show waiting message when not in team', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
          p3: createPlayer('p3', 'Charlie'),
        }}
        currentPlayer={createPlayer('p3', 'Charlie')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p3"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('รอทีมทำภารกิจ')).toBeInTheDocument();
  });

  it('should show success and fail cards when in team', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'assassin' as Role, team: 'evil', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    expect(screen.getByText('เลือกการ์ดภารกิจ')).toBeInTheDocument();
    expect(screen.getByText('สำเร็จ')).toBeInTheDocument();
    expect(screen.getByText('ล้มเหลว')).toBeInTheDocument();
  });

  it('should disable fail card for good players', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'merlin' as Role, team: 'good', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    const failButton = screen.getByText('ล้มเหลว').closest('button')!;
    expect(failButton).toBeDisabled();
    expect(screen.getByText('ฝ่าย Good ไม่สามารถเลือกได้')).toBeInTheDocument();
  });

  it('should call onSubmitQuestCard with success when success button is clicked', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'assassin' as Role, team: 'evil', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('สำเร็จ'));
    
    expect(mockOnSubmitQuestCard).toHaveBeenCalledWith('success');
  });

  it('should call onSubmitQuestCard with fail when fail button is clicked', () => {
    render(
      <ControllerMode
        roomId="ABC123"
        publicBoard={publicBoard}
        players={{ 
          p1: createPlayer('p1', 'Alice'),
          p2: createPlayer('p2', 'Bob'),
        }}
        currentPlayer={createPlayer('p1', 'Alice')}
        privateRole={{ role: 'assassin' as Role, team: 'evil', knownPlayers: [] }}
        playerId="p1"
        onSelectTeam={mockOnSelectTeam}
        onSubmitVote={mockOnSubmitVote}
        onSubmitQuestCard={mockOnSubmitQuestCard}
        onSubmitAssassination={mockOnSubmitAssassination}
        onSetReady={mockOnSetReady}
      />
    );
    
    fireEvent.click(screen.getByText('ล้มเหลว'));
    
    expect(mockOnSubmitQuestCard).toHaveBeenCalledWith('fail');
  });
});

/**
 * @vitest-environment jsdom
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { JoinRoom } from '@/components/JoinRoom';

vi.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  },
}));

describe('JoinRoom Component', () => {
  const mockOnJoin = vi.fn();
  const mockOnBack = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should render title correctly', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    expect(screen.getByText('เข้าร่วมห้อง')).toBeInTheDocument();
  });

  it('should render room code input', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    expect(screen.getByPlaceholderText('เช่น ABC123')).toBeInTheDocument();
  });

  it('should render name input', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    expect(screen.getByPlaceholderText('ใส่ชื่อเล่น')).toBeInTheDocument();
  });

  it('should pre-fill room code when provided', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false}
        preFillRoomCode="XYZ789"
      />
    );
    
    const roomInput = screen.getByPlaceholderText('เช่น ABC123') as HTMLInputElement;
    expect(roomInput.value).toBe('XYZ789');
    expect(screen.getByText('✓ รหัสห้องจาก QR Code')).toBeInTheDocument();
  });

  it('should call onBack when back button is clicked', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    const backButton = screen.getByText('กลับ');
    fireEvent.click(backButton);
    
    expect(mockOnBack).toHaveBeenCalledTimes(1);
  });

  it('should show error message when error is provided', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error="Invalid room code" 
        loading={false} 
      />
    );
    
    expect(screen.getByText('Invalid room code')).toBeInTheDocument();
  });

  it('should disable join button when inputs are empty', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    const joinButton = screen.getByText('เข้าร่วมห้อง');
    expect(joinButton).toBeDisabled();
  });

  it('should enable join button when inputs are filled', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    const roomInput = screen.getByPlaceholderText('เช่น ABC123');
    const nameInput = screen.getByPlaceholderText('ใส่ชื่อเล่น');
    
    fireEvent.change(roomInput, { target: { value: 'ABC123' } });
    fireEvent.change(nameInput, { target: { value: 'Player1' } });
    
    const joinButton = screen.getByText('เข้าร่วมห้อง');
    expect(joinButton).not.toBeDisabled();
  });

  it('should call onJoin with room code and name when form is submitted', async () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    const roomInput = screen.getByPlaceholderText('เช่น ABC123');
    const nameInput = screen.getByPlaceholderText('ใส่ชื่อเล่น');
    
    fireEvent.change(roomInput, { target: { value: 'ABC123' } });
    fireEvent.change(nameInput, { target: { value: 'Player1' } });
    
    const joinButton = screen.getByText('เข้าร่วมห้อง');
    fireEvent.click(joinButton);
    
    await waitFor(() => {
      expect(mockOnJoin).toHaveBeenCalledWith('ABC123', 'Player1');
    });
  });

  it('should convert room code to uppercase', async () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={false} 
      />
    );
    
    const roomInput = screen.getByPlaceholderText('เช่น ABC123');
    const nameInput = screen.getByPlaceholderText('ใส่ชื่อเล่น');
    
    fireEvent.change(roomInput, { target: { value: 'abc123' } });
    fireEvent.change(nameInput, { target: { value: 'Player1' } });
    
    const joinButton = screen.getByText('เข้าร่วมห้อง');
    fireEvent.click(joinButton);
    
    await waitFor(() => {
      expect(mockOnJoin).toHaveBeenCalledWith('ABC123', 'Player1');
    });
  });

  it('should show loading state when loading is true', () => {
    render(
      <JoinRoom 
        onJoin={mockOnJoin} 
        onBack={mockOnBack} 
        error={null} 
        loading={true} 
      />
    );
    
    expect(screen.getByText('กำลังเข้าร่วม...')).toBeInTheDocument();
  });
});

/**
 * @vitest-environment jsdom
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { HomeScreen } from '@/components/HomeScreen';

// Mock framer-motion
vi.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  },
}));

describe('HomeScreen Component', () => {
  const mockOnCreateRoom = vi.fn();
  const mockOnJoinRoom = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should render title and subtitle correctly', () => {
    render(<HomeScreen onCreateRoom={mockOnCreateRoom} onJoinRoom={mockOnJoinRoom} />);
    
    expect(screen.getByText('AVALON')).toBeInTheDocument();
    expect(screen.getByText('The Resistance')).toBeInTheDocument();
    expect(screen.getByText('ระบบช่วยเล่นเกมแบบ Real-time')).toBeInTheDocument();
  });

  it('should render both mode buttons', () => {
    render(<HomeScreen onCreateRoom={mockOnCreateRoom} onJoinRoom={mockOnJoinRoom} />);
    
    expect(screen.getByText('สร้างห้อง (TV Mode)')).toBeInTheDocument();
    expect(screen.getByText('เข้าร่วม (Controller)')).toBeInTheDocument();
  });

  it('should call onCreateRoom when TV Mode button is clicked', () => {
    render(<HomeScreen onCreateRoom={mockOnCreateRoom} onJoinRoom={mockOnJoinRoom} />);
    
    const createButton = screen.getByText('สร้างห้อง (TV Mode)');
    fireEvent.click(createButton);
    
    expect(mockOnCreateRoom).toHaveBeenCalledTimes(1);
  });

  it('should call onJoinRoom when Controller button is clicked', () => {
    render(<HomeScreen onCreateRoom={mockOnCreateRoom} onJoinRoom={mockOnJoinRoom} />);
    
    const joinButton = screen.getByText('เข้าร่วม (Controller)');
    fireEvent.click(joinButton);
    
    expect(mockOnJoinRoom).toHaveBeenCalledTimes(1);
  });

  it('should display player count info', () => {
    render(<HomeScreen onCreateRoom={mockOnCreateRoom} onJoinRoom={mockOnJoinRoom} />);
    
    expect(screen.getByText('รองรับ 5-10 ผู้เล่น')).toBeInTheDocument();
  });

  it('should show description text', () => {
    render(<HomeScreen onCreateRoom={mockOnCreateRoom} onJoinRoom={mockOnJoinRoom} />);
    
    expect(screen.getByText(/เกมกลยุทธ์สืบหาผู้ทรยศ/)).toBeInTheDocument();
  });
});

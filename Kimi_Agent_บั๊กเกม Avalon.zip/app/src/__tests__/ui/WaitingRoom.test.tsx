/**
 * @vitest-environment jsdom
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { WaitingRoom } from '@/components/WaitingRoom';
import type { Player } from '@/types';

vi.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  },
  AnimatePresence: ({ children }: any) => <>{children}</>,
}));

describe('WaitingRoom Component', () => {
  const mockOnLeave = vi.fn();
  
  const createPlayer = (id: string, name: string): Player => ({
    id,
    name,
    seatIndex: 0,
    isOnline: true,
    isLeader: false,
    joinedAt: Date.now(),
  });

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should render room title', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    expect(screen.getByText('ห้องรอ')).toBeInTheDocument();
  });

  it('should display room code', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    expect(screen.getByText('ABC123')).toBeInTheDocument();
  });

  it('should display player count', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    expect(screen.getByText(/0.*\/.*7.*ผู้เล่น/)).toBeInTheDocument();
  });

  it('should display list of players', () => {
    const players = [
      createPlayer('p1', 'Alice'),
      createPlayer('p2', 'Bob'),
      createPlayer('p3', 'Charlie'),
    ];
    
    render(
      <WaitingRoom
        roomId="ABC123"
        players={players}
        currentPlayer={players[0]}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    expect(screen.getByText('Alice')).toBeInTheDocument();
    expect(screen.getByText('Bob')).toBeInTheDocument();
    expect(screen.getByText('Charlie')).toBeInTheDocument();
  });

  it('should mark current player with "คุณ" badge', () => {
    const players = [
      createPlayer('p1', 'Alice'),
      createPlayer('p2', 'Bob'),
    ];
    
    render(
      <WaitingRoom
        roomId="ABC123"
        players={players}
        currentPlayer={players[0]}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    expect(screen.getByText('คุณ')).toBeInTheDocument();
  });

  it('should call onLeave when leave button is clicked', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    const leaveButton = screen.getByText('ออก');
    fireEvent.click(leaveButton);
    
    expect(mockOnLeave).toHaveBeenCalledTimes(1);
  });

  it('should show role guide button', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    expect(screen.getByText('แสดงคู่มือบทบาท')).toBeInTheDocument();
  });

  it('should toggle role guide when button is clicked', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    const roleGuideButton = screen.getByText('แสดงคู่มือบทบาท');
    fireEvent.click(roleGuideButton);
    
    expect(screen.getByText('ซ่อนคู่มือบทบาท')).toBeInTheDocument();
    expect(screen.getByText('บทบาทในเกม')).toBeInTheDocument();
  });

  it('should show waiting message', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    expect(screen.getByText('รอ Host เริ่มเกม...')).toBeInTheDocument();
  });

  it('should show empty slots for remaining players', () => {
    const players = [createPlayer('p1', 'Alice')];
    
    render(
      <WaitingRoom
        roomId="ABC123"
        players={players}
        currentPlayer={players[0]}
        maxPlayers={5}
        onLeave={mockOnLeave}
      />
    );
    
    const emptySlots = screen.getAllByText('รอผู้เล่น...');
    expect(emptySlots.length).toBe(4); // 5 max - 1 player = 4 empty slots
  });

  it('should display good team roles in guide', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    const roleGuideButton = screen.getByText('แสดงคู่มือบทบาท');
    fireEvent.click(roleGuideButton);
    
    expect(screen.getByText('ฝ่ายผู้ภักดี (Good)')).toBeInTheDocument();
  });

  it('should display evil team roles in guide', () => {
    render(
      <WaitingRoom
        roomId="ABC123"
        players={[]}
        currentPlayer={null}
        maxPlayers={7}
        onLeave={mockOnLeave}
      />
    );
    
    const roleGuideButton = screen.getByText('แสดงคู่มือบทบาท');
    fireEvent.click(roleGuideButton);
    
    expect(screen.getByText('ฝ่ายลูกสมุน (Evil)')).toBeInTheDocument();
  });
});

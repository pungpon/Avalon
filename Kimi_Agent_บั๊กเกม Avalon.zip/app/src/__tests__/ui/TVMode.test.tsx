/**
 * @vitest-environment jsdom
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { TVMode } from '@/components/TVMode';
import type { Player, GameState } from '@/types';

vi.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  },
  AnimatePresence: ({ children }: any) => <>{children}</>,
}));

vi.mock('qrcode.react', () => ({
  QRCodeSVG: ({ value }: any) => <div data-testid="qrcode">QR: {value}</div>,
}));

describe('TVMode Component - Lobby', () => {
  const mockOnCreateRoom = vi.fn();
  const mockOnStartGame = vi.fn();
  const mockOnNextRound = vi.fn();
  const mockOnResetGame = vi.fn();
  const mockOnCancel = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should render room creation screen when no roomId', () => {
    render(
      <TVMode
        roomId={null}
        gameState={null}
        publicBoard={null}
        players={[]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('สร้างห้องใหม่')).toBeInTheDocument();
    expect(screen.getByText('เลือกจำนวนผู้เล่น')).toBeInTheDocument();
  });

  it('should render player count buttons (5-10)', () => {
    render(
      <TVMode
        roomId={null}
        gameState={null}
        publicBoard={null}
        players={[]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    ['5', '6', '7', '8', '9', '10'].forEach(num => {
      expect(screen.getByText(num)).toBeInTheDocument();
    });
  });

  it('should call onCreateRoom with selected player count', () => {
    render(
      <TVMode
        roomId={null}
        gameState={null}
        publicBoard={null}
        players={[]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    fireEvent.click(screen.getByText('7'));
    fireEvent.click(screen.getByText('สร้างห้อง'));
    
    expect(mockOnCreateRoom).toHaveBeenCalledWith(7);
  });

  it('should call onCancel when cancel button is clicked', () => {
    render(
      <TVMode
        roomId={null}
        gameState={null}
        publicBoard={null}
        players={[]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    fireEvent.click(screen.getByText('ยกเลิก'));
    
    expect(mockOnCancel).toHaveBeenCalledTimes(1);
  });

  it('should show team distribution info', () => {
    render(
      <TVMode
        roomId={null}
        gameState={null}
        publicBoard={null}
        players={[]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('การแบ่งทีม')).toBeInTheDocument();
    expect(screen.getByText(/Good/)).toBeInTheDocument();
    expect(screen.getByText(/Evil/)).toBeInTheDocument();
  });
});

describe('TVMode Component - Waiting Room', () => {
  const mockOnCreateRoom = vi.fn();
  const mockOnStartGame = vi.fn();
  const mockOnNextRound = vi.fn();
  const mockOnResetGame = vi.fn();
  const mockOnCancel = vi.fn();

  const createPlayer = (id: string, name: string): Player => ({
    id,
    name,
    seatIndex: 0,
    isOnline: true,
    isLeader: false,
    joinedAt: Date.now(),
  });

  const mockGameState: GameState = {
    roomId: 'ABC123',
    meta: {
      hostDeviceId: 'host1',
      status: 'waiting',
      createdAt: Date.now(),
      config: {
        playerCount: 7,
        roles: ['merlin', 'assassin', 'percival', 'morgana', 'mordred', 'loyal', 'loyal'],
        useExcalibur: false,
        language: 'th',
      },
    },
    publicBoard: {
      phase: 'lobby',
      round: 0,
      leaderId: null,
      questResults: [null, null, null, null, null],
      currentTeam: [],
      teamSize: 2,
      voteStatus: { total: 0, casted: 0, revealed: false, approveCount: 0, rejectCount: 0 },
      questStatus: { submitted: 0, required: 1, failCount: 0 },
      winner: null,
      logs: [],
      rejectedTeamsCount: 0,
      assassinationTarget: null,
    },
    players: {},
  };

  it('should display room code when in lobby', () => {
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={[]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('ABC123')).toBeInTheDocument();
  });

  it('should display QR code', () => {
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={[]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByTestId('qrcode')).toBeInTheDocument();
  });

  it('should display player list', () => {
    const players = [
      createPlayer('p1', 'Alice'),
      createPlayer('p2', 'Bob'),
    ];
    
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={players}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('Alice')).toBeInTheDocument();
    expect(screen.getByText('Bob')).toBeInTheDocument();
  });

  it('should display player count', () => {
    const players = [
      createPlayer('p1', 'Alice'),
      createPlayer('p2', 'Bob'),
    ];
    
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={players}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText(/2.*\/.*7/)).toBeInTheDocument();
  });

  it('should disable start game button with less than 5 players', () => {
    const players = [
      createPlayer('p1', 'Alice'),
      createPlayer('p2', 'Bob'),
      createPlayer('p3', 'Charlie'),
      createPlayer('p4', 'David'),
    ];
    
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={players}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    const startButton = screen.getByText(/ต้องการอีก/);
    expect(startButton).toBeDisabled();
  });

  it('should enable start game button with 5+ players', () => {
    const players = [
      createPlayer('p1', 'Alice'),
      createPlayer('p2', 'Bob'),
      createPlayer('p3', 'Charlie'),
      createPlayer('p4', 'David'),
      createPlayer('p5', 'Eve'),
    ];
    
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={players}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    const startButton = screen.getByText('เริ่มเกม');
    expect(startButton).not.toBeDisabled();
  });

  it('should call onStartGame when start button is clicked', () => {
    const players = [
      createPlayer('p1', 'Alice'),
      createPlayer('p2', 'Bob'),
      createPlayer('p3', 'Charlie'),
      createPlayer('p4', 'David'),
      createPlayer('p5', 'Eve'),
    ];
    
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={players}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    fireEvent.click(screen.getByText('เริ่มเกม'));
    
    expect(mockOnStartGame).toHaveBeenCalledTimes(1);
  });
});

describe('TVMode Component - Game Board', () => {
  const mockOnCreateRoom = vi.fn();
  const mockOnStartGame = vi.fn();
  const mockOnNextRound = vi.fn();
  const mockOnResetGame = vi.fn();
  const mockOnCancel = vi.fn();

  const createPlayer = (id: string, name: string): Player => ({
    id,
    name,
    seatIndex: 0,
    isOnline: true,
    isLeader: false,
    joinedAt: Date.now(),
  });

  const mockGameState: GameState = {
    roomId: 'ABC123',
    meta: {
      hostDeviceId: 'host1',
      status: 'playing',
      createdAt: Date.now(),
      config: {
        playerCount: 5,
        roles: ['merlin', 'assassin', 'percival', 'morgana', 'loyal'],
        useExcalibur: false,
        language: 'th',
      },
    },
    publicBoard: {
      phase: 'team-selection',
      round: 0,
      leaderId: 'p1',
      questResults: [null, null, null, null, null],
      currentTeam: [],
      teamSize: 2,
      voteStatus: { total: 5, casted: 0, revealed: false, approveCount: 0, rejectCount: 0 },
      questStatus: { submitted: 0, required: 1, failCount: 0 },
      winner: null,
      logs: [],
      rejectedTeamsCount: 0,
      assassinationTarget: null,
    },
    players: {},
  };

  it('should display game title', () => {
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={[createPlayer('p1', 'Alice')]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('AVALON')).toBeInTheDocument();
  });

  it('should display score', () => {
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={[createPlayer('p1', 'Alice')]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('Good')).toBeInTheDocument();
    expect(screen.getByText('Evil')).toBeInTheDocument();
  });

  it('should display quest track', () => {
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={[createPlayer('p1', 'Alice')]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('Q1')).toBeInTheDocument();
    expect(screen.getByText('Q2')).toBeInTheDocument();
    expect(screen.getByText('Q3')).toBeInTheDocument();
    expect(screen.getByText('Q4')).toBeInTheDocument();
    expect(screen.getByText('Q5')).toBeInTheDocument();
  });

  it('should display current phase', () => {
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={[createPlayer('p1', 'Alice')]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText('team-selection')).toBeInTheDocument();
  });

  it('should display leader name', () => {
    render(
      <TVMode
        roomId="ABC123"
        gameState={mockGameState}
        publicBoard={mockGameState.publicBoard}
        players={[createPlayer('p1', 'Alice')]}
        onCreateRoom={mockOnCreateRoom}
        onStartGame={mockOnStartGame}
        onNextRound={mockOnNextRound}
        onResetGame={mockOnResetGame}
        loading={false}
        onCancel={mockOnCancel}
      />
    );
    
    expect(screen.getByText(/หัวหน้า:/)).toBeInTheDocument();
  });
});

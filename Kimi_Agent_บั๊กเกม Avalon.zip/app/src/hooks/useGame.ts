// Custom hook for game state management
import { useState, useCallback, useRef } from 'react';
import { 
  subscribeToRoom, 
  subscribeToPrivateRole,
  updatePublicBoard,
  submitVote as submitVoteToDB,
  submitQuestCard as submitQuestCardToDB,
  revealVotes as revealVotesFromDB,
  revealQuestCards as revealQuestCardsFromDB,
  assignRoles as assignRolesToDB,
  addLog,
  startGame as startGameDB,
  endGame as endGameDB,
  resetRoom as resetRoomDB,
  createRoom,
  joinRoom,
  generateRoomCode,
  generatePlayerId,
  updatePlayerOnlineStatus
} from '@/lib/firebase';
import { getDatabase, ref, remove } from 'firebase/database';
import { 
  assignRoles as assignRolesLogic, 
  getTeamSize, 
  determineQuestResult,
  checkWinner,
  determineVoteResult,
  checkEvilWinsByRejections,
  getNextLeaderIndex,
  assignSeatIndices,
  checkAssassination,
  getDefaultRoles,
  getPhaseMessage,
  requiresTwoFails
} from '@/lib/gameLogic';
import type { GameState, Player, Role, VoteValue, QuestCard } from '@/types';

// Generate or get stored player ID
const getStoredPlayerId = (): string => {
  let playerId = localStorage.getItem('avalon_player_id');
  if (!playerId) {
    playerId = generatePlayerId();
    localStorage.setItem('avalon_player_id', playerId);
  }
  return playerId;
};

export const useGame = () => {
  const [roomId, setRoomId] = useState<string | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [publicBoard, setPublicBoard] = useState<any>(null);
  const [players, setPlayers] = useState<Record<string, Player>>({});
  const [privateRole, setPrivateRole] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const playerId = useRef<string>(getStoredPlayerId()).current;
  const unsubscribeRef = useRef<(() => void) | null>(null);

  // Subscribe to room data
  const subscribeToRoomData = useCallback((roomId: string) => {
    setLoading(true);
    setRoomId(roomId);
    
    // Subscribe to full room data
    const unsubscribe = subscribeToRoom(roomId, (data) => {
      if (data) {
        setGameState(data);
        setPublicBoard(data.publicBoard);
        setPlayers(data.players || {});
      } else {
        setError('Room not found');
      }
      setLoading(false);
    });
    
    unsubscribeRef.current = unsubscribe;
    
    // Subscribe to private role
    const unsubscribeRole = subscribeToPrivateRole(roomId, playerId, (role) => {
      setPrivateRole(role);
    });
    
    return () => {
      unsubscribe();
      unsubscribeRole();
    };
  }, [playerId]);

  // Create new room (for TV/Host)
  const createNewRoom = useCallback(async (playerCount: number = 7, selectedRoles?: Role[]) => {
    try {
      setLoading(true);
      const newRoomId = generateRoomCode();
      const roles = selectedRoles || getDefaultRoles(playerCount);
      
      await createRoom(newRoomId, playerId, {
        playerCount,
        roles,
        useExcalibur: false,
        language: 'th',
      });
      
      setRoomId(newRoomId);
      subscribeToRoomData(newRoomId);
      
      return newRoomId;
    } catch (err) {
      setError('Failed to create room');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [playerId, subscribeToRoomData]);

  // Join existing room
  const joinExistingRoom = useCallback(async (roomCode: string, playerName: string) => {
    try {
      setLoading(true);
      const normalizedRoomId = roomCode.toUpperCase().trim();
      
      await joinRoom(normalizedRoomId, playerId, {
        name: playerName,
        seatIndex: -1, // Will be assigned when game starts
        isLeader: false,
      });
      
      subscribeToRoomData(normalizedRoomId);
      
      return normalizedRoomId;
    } catch (err) {
      setError('Failed to join room');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [playerId, subscribeToRoomData]);

  // Start game (Host only)
  const startGame = useCallback(async () => {
    if (!roomId || !gameState) return;
    
    const playerList = Object.keys(players);
    if (playerList.length < 5) {
      setError('Need at least 5 players');
      return;
    }
    
    try {
      setLoading(true);
      
      // Assign seat indices
      const seatAssignments = assignSeatIndices(playerList);
      
      // Update player seat indices
      for (const [pid, seatIndex] of Object.entries(seatAssignments)) {
        await updatePublicBoard(roomId, { [`players/${pid}/seatIndex`]: seatIndex });
      }
      
      // Assign roles
      const roles = gameState.meta.config.roles || getDefaultRoles(playerList.length);
      const roleAssignments = assignRolesLogic(playerList, roles);
      await assignRolesToDB(roomId, roleAssignments);
      
      // Set initial leader (random)
      const leaderId = playerList[Math.floor(Math.random() * playerList.length)];
      
      // Update public board
      await updatePublicBoard(roomId, {
        leaderId,
        teamSize: getTeamSize(playerList.length, 0),
        [`players/${leaderId}/isLeader`]: true,
      });
      
      // Start game
      await startGameDB(roomId, playerList.length);
      
      await addLog(roomId, 'Game started!', 'info');
      
    } catch (err) {
      setError('Failed to start game');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [roomId, gameState, players]);

  // Select team (Leader only)
  const selectTeam = useCallback(async (selectedPlayerIds: string[]) => {
    if (!roomId || !publicBoard) return;
    
    const currentPlayer = players[playerId];
    if (!currentPlayer?.isLeader) {
      setError('Only leader can select team');
      return;
    }
    
    const requiredSize = publicBoard.teamSize;
    if (selectedPlayerIds.length !== requiredSize) {
      setError(`Must select exactly ${requiredSize} players`);
      return;
    }
    
    try {
      await updatePublicBoard(roomId, {
        currentTeam: selectedPlayerIds,
        phase: 'voting',
        'voteStatus': {
          total: Object.keys(players).length,
          casted: 0,
          revealed: false,
          approveCount: 0,
          rejectCount: 0,
        },
      });
      
      await addLog(roomId, `Team proposed: ${selectedPlayerIds.map(id => players[id]?.name).join(', ')}`, 'info');
    } catch (err) {
      setError('Failed to select team');
      throw err;
    }
  }, [roomId, publicBoard, players, playerId]);

  // Submit vote
  const submitVote = useCallback(async (vote: VoteValue) => {
    if (!roomId || !publicBoard) return;
    
    try {
      await submitVoteToDB(roomId, publicBoard.round, playerId, vote);
      
      // Check if all votes are in
      const voteRef = publicBoard.voteStatus;
      if (voteRef.casted + 1 >= voteRef.total) {
        // Reveal votes
        const result = await revealVotesFromDB(roomId, publicBoard.round);
        const voteResult = determineVoteResult(result.approveCount, result.rejectCount);
        
        if (voteResult === 'approved') {
          await updatePublicBoard(roomId, { phase: 'quest' });
          await addLog(roomId, `Team approved (${result.approveCount}-${result.rejectCount})`, 'success');
        } else {
          const newRejectionCount = (publicBoard.rejectedTeamsCount || 0) + 1;
          
          if (checkEvilWinsByRejections(newRejectionCount)) {
            await endGameDB(roomId, 'evil');
            await addLog(roomId, 'Evil wins! 5 teams rejected.', 'fail');
          } else {
            // Move to next leader
            const playerList = Object.keys(players);
            const currentLeader = players[publicBoard.leaderId];
            const nextLeaderIndex = getNextLeaderIndex(currentLeader.seatIndex, playerList.length);
            const nextLeaderId = Object.values(players).find(p => p.seatIndex === nextLeaderIndex)?.id;
            
            await updatePublicBoard(roomId, {
              phase: 'team-selection',
              leaderId: nextLeaderId,
              rejectedTeamsCount: newRejectionCount,
              currentTeam: [],
              [`players/${publicBoard.leaderId}/isLeader`]: false,
              [`players/${nextLeaderId}/isLeader`]: true,
            });
            
            await addLog(roomId, `Team rejected (${result.approveCount}-${result.rejectCount}). Rejection ${newRejectionCount}/5`, 'warning');
          }
        }
      }
    } catch (err) {
      setError('Failed to submit vote');
      throw err;
    }
  }, [roomId, publicBoard, playerId, players]);

  // Submit quest card
  const submitQuestCard = useCallback(async (card: QuestCard) => {
    if (!roomId || !publicBoard) return;
    
    // Check if player is in the team
    if (!publicBoard.currentTeam.includes(playerId)) {
      setError('Only team members can submit quest cards');
      return;
    }
    
    try {
      await submitQuestCardToDB(roomId, publicBoard.round, playerId, card);
      
      // Check if all cards are in
      const teamSize = publicBoard.currentTeam.length;
      const submittedCount = (publicBoard.questStatus?.submitted || 0) + 1;
      
      await updatePublicBoard(roomId, {
        'questStatus.submitted': submittedCount,
      });
      
      if (submittedCount >= teamSize) {
        // Reveal quest cards
        const result = await revealQuestCardsFromDB(roomId, publicBoard.round);
        const playerCount = Object.keys(players).length;
        const questResult = determineQuestResult(playerCount, publicBoard.round, result.cards);
        
        // Update quest results
        const newQuestResults = [...publicBoard.questResults];
        newQuestResults[publicBoard.round] = questResult;
        
        await updatePublicBoard(roomId, {
          questResults: newQuestResults,
          phase: 'quest-result',
        });
        
        await addLog(roomId, `Quest ${publicBoard.round + 1} ${questResult.toUpperCase()}!`, questResult === 'success' ? 'success' : 'fail');
        
        // Check winner
        const winner = checkWinner(newQuestResults);
        
        if (winner) {
          if (winner === 'good') {
            // Go to assassination phase
            await updatePublicBoard(roomId, { phase: 'assassination' });
          } else {
            await endGameDB(roomId, 'evil');
          }
        }
      }
    } catch (err) {
      setError('Failed to submit quest card');
      throw err;
    }
  }, [roomId, publicBoard, playerId, players]);

  // Submit assassination target
  const submitAssassination = useCallback(async (targetId: string) => {
    if (!roomId || !gameState) return;
    
    // Check if player is Assassin or Evil
    const isAssassin = privateRole?.role === 'assassin';
    const isEvil = privateRole?.team === 'evil';
    
    if (!isAssassin && !isEvil) {
      setError('Only Evil can assassinate');
      return;
    }
    
    try {
      const isMerlin = checkAssassination(targetId, gameState.privateRoles || {});
      
      await updatePublicBoard(roomId, {
        assassinationTarget: targetId,
      });
      
      if (isMerlin) {
        await endGameDB(roomId, 'evil');
        await addLog(roomId, 'Assassin killed Merlin! Evil wins!', 'fail');
      } else {
        await endGameDB(roomId, 'good');
        await addLog(roomId, 'Assassin missed! Good wins!', 'success');
      }
    } catch (err) {
      setError('Failed to submit assassination');
      throw err;
    }
  }, [roomId, gameState, privateRole]);

  // Move to next round
  const nextRound = useCallback(async () => {
    if (!roomId || !publicBoard) return;
    
    try {
      const nextRound = publicBoard.round + 1;
      const playerList = Object.keys(players);
      
      // Move to next leader
      const currentLeader = players[publicBoard.leaderId];
      const nextLeaderIndex = getNextLeaderIndex(currentLeader.seatIndex, playerList.length);
      const nextLeaderId = Object.values(players).find(p => p.seatIndex === nextLeaderIndex)?.id;
      
      await updatePublicBoard(roomId, {
        round: nextRound,
        phase: 'team-selection',
        leaderId: nextLeaderId,
        teamSize: getTeamSize(playerList.length, nextRound),
        currentTeam: [],
        rejectedTeamsCount: 0,
        [`players/${publicBoard.leaderId}/isLeader`]: false,
        [`players/${nextLeaderId}/isLeader`]: true,
        voteStatus: {
          total: 0,
          casted: 0,
          revealed: false,
          approveCount: 0,
          rejectCount: 0,
        },
        questStatus: {
          submitted: 0,
          required: requiresTwoFails(playerList.length, nextRound) ? 2 : 1,
          failCount: 0,
        },
      });
    } catch (err) {
      setError('Failed to move to next round');
      throw err;
    }
  }, [roomId, publicBoard, players]);

  // Reset game
  const resetGame = useCallback(async () => {
    if (!roomId) return;
    
    try {
      await resetRoomDB(roomId);
      setPrivateRole(null);
    } catch (err) {
      setError('Failed to reset game');
      throw err;
    }
  }, [roomId]);

  // Set player ready
  const setPlayerReady = useCallback(async () => {
    if (!roomId) return;
    
    try {
      await updatePublicBoard(roomId, {
        [`players/${playerId}/isReady`]: true,
      });
    } catch (err) {
      setError('Failed to set ready');
      throw err;
    }
  }, [roomId, playerId]);

  // Mark player as online
  const setOnline = useCallback(async (isOnline: boolean) => {
    if (!roomId) return;
    
    try {
      await updatePlayerOnlineStatus(roomId, playerId, isOnline);
    } catch (err) {
      console.error('Failed to update online status:', err);
    }
  }, [roomId, playerId]);

  // Clear error
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Leave room
  const leaveRoom = useCallback(async () => {
    if (!roomId) return;
    
    try {
      const database = getDatabase();
      const playerRef = ref(database, `rooms/${roomId}/players/${playerId}`);
      await remove(playerRef);
      
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
      }
      
      setRoomId(null);
      setGameState(null);
      setPublicBoard(null);
      setPlayers({});
      setPrivateRole(null);
    } catch (err) {
      console.error('Failed to leave room:', err);
    }
  }, [roomId, playerId]);

  // Get current player
  const currentPlayer = players[playerId];

  // Get phase message
  const phaseMessage = publicBoard ? getPhaseMessage(publicBoard.phase, 'th') : '';

  return {
    // State
    roomId,
    gameState,
    publicBoard,
    players,
    privateRole,
    currentPlayer,
    playerId,
    loading,
    error,
    phaseMessage,
    
    // Actions
    createNewRoom,
    joinExistingRoom,
    startGame,
    selectTeam,
    submitVote,
    submitQuestCard,
    submitAssassination,
    nextRound,
    resetGame,
    setPlayerReady,
    setOnline,
    clearError,
    leaveRoom,
    subscribeToRoomData,
  };
};

export default useGame;

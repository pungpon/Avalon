// Join Room Component
import { useState, useEffect } from 'react';
import { ArrowLeft, Users, Loader2, ScanLine } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';

interface JoinRoomProps {
  onJoin: (roomCode: string, playerName: string) => void;
  onBack: () => void;
  error: string | null;
  loading: boolean;
  preFillRoomCode?: string;
}

export const JoinRoom = ({ onJoin, onBack, error, loading, preFillRoomCode = '' }: JoinRoomProps) => {
  const [roomCode, setRoomCode] = useState(preFillRoomCode);
  const [playerName, setPlayerName] = useState('');

  // Update room code when preFillRoomCode changes
  useEffect(() => {
    if (preFillRoomCode) {
      setRoomCode(preFillRoomCode);
    }
  }, [preFillRoomCode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (roomCode.trim() && playerName.trim()) {
      onJoin(roomCode.trim().toUpperCase(), playerName.trim());
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-4 text-slate-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          กลับ
        </Button>

        <Card className="bg-white/5 backdrop-blur-sm border-white/10">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-white flex items-center justify-center gap-2">
              <ScanLine className="w-6 h-6 text-purple-400" />
              เข้าร่วมห้อง
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-slate-300 mb-2">
                  รหัสห้อง (6 ตัว)
                </label>
                <Input
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                  placeholder="เช่น ABC123"
                  maxLength={6}
                  className="bg-white/10 border-white/20 text-white text-center text-2xl tracking-widest uppercase"
                  disabled={loading}
                  autoFocus={!preFillRoomCode}
                />
                {preFillRoomCode && (
                  <p className="text-xs text-green-400 mt-1 text-center">
                    ✓ รหัสห้องจาก QR Code
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm text-slate-300 mb-2">
                  ชื่อของคุณ
                </label>
                <Input
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="ใส่ชื่อเล่น"
                  maxLength={20}
                  className="bg-white/10 border-white/20 text-white"
                  disabled={loading}
                  autoFocus={!!preFillRoomCode}
                />
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-3 bg-red-500/20 border border-red-500/30 rounded-lg text-red-300 text-sm text-center"
                >
                  {error}
                </motion.div>
              )}

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-500 hover:to-blue-700"
                disabled={!roomCode.trim() || !playerName.trim() || loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังเข้าร่วม...
                  </>
                ) : (
                  <>
                    <Users className="w-4 h-4 mr-2" />
                    เข้าร่วมห้อง
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Instructions */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center text-slate-500 text-sm mt-6"
        >
          สแกน QR Code บนหน้าจอ Host เพื่อเข้าร่วมอัตโนมัติ
        </motion.p>
      </motion.div>
    </div>
  );
};

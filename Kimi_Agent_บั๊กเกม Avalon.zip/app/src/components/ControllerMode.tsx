// Controller Mode Component - Private Interface for Players
import { useState, useEffect } from 'react';
import { Crown, Check, X, Skull, Shield, Sword, UserCheck, UserX, ChevronRight, Sparkles, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import type { Player, Role, VoteValue, QuestCard } from '@/types';
import { ROLE_DEFINITIONS } from '@/types';

interface ControllerModeProps {
  roomId: string | null;
  publicBoard: any;
  players: Record<string, Player>;
  currentPlayer: Player | null;
  privateRole: { role: Role; team: 'good' | 'evil'; knownPlayers: string[]; knownRoles?: Record<string, Role> } | null;
  playerId: string;
  onSelectTeam: (selectedPlayerIds: string[]) => void;
  onSubmitVote: (vote: VoteValue) => void;
  onSubmitQuestCard: (card: QuestCard) => void;
  onSubmitAssassination: (targetId: string) => void;
  onSetReady: () => void;
}

// Role reveal animation component
const RoleRevealAnimation = ({ 
  finalRole, 
  onComplete 
}: { 
  finalRole: Role; 
  onComplete: () => void;
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRevealing, setIsRevealing] = useState(true);
  const allRoles = Object.keys(ROLE_DEFINITIONS) as Role[];
  
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    let timeout: ReturnType<typeof setTimeout>;
    
    if (isRevealing) {
      // Shuffle through roles
      interval = setInterval(() => {
        setCurrentIndex(prev => (prev + 1) % allRoles.length);
      }, 100);
      
      // Stop after 2 seconds and show final role
      timeout = setTimeout(() => {
        clearInterval(interval);
        setIsRevealing(false);
        const finalIndex = allRoles.indexOf(finalRole);
        setCurrentIndex(finalIndex);
        setTimeout(onComplete, 1000);
      }, 2000);
    }
    
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [finalRole, allRoles, isRevealing, onComplete]);

  const displayRole = allRoles[currentIndex];
  const roleDef = ROLE_DEFINITIONS[displayRole];
  const isGood = roleDef.team === 'good';

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/90 flex flex-col items-center justify-center z-50"
    >
      <motion.div
        animate={isRevealing ? { scale: [1, 1.05, 1] } : {}}
        transition={{ repeat: Infinity, duration: 0.2 }}
        className="text-center"
      >
        <Sparkles className="w-12 h-12 mx-auto mb-4 text-yellow-400 animate-pulse" />
        <h2 className="text-2xl font-bold mb-8">
          {isRevealing ? 'กำลังสุ่มบทบาท...' : 'บทบาทของคุณ!'}
        </h2>
        
        <motion.div
          className={`
            w-48 h-64 rounded-2xl flex flex-col items-center justify-center border-4
            ${isGood ? 'bg-blue-500/20 border-blue-500' : 'bg-red-500/20 border-red-500'}
            ${!isRevealing && displayRole === finalRole ? 'ring-4 ring-yellow-400/50' : ''}
          `}
        >
          <div className="text-6xl mb-4">
            {isGood ? <Shield className="w-20 h-20" /> : <Sword className="w-20 h-20" />}
          </div>
          <h3 className="text-2xl font-bold">{roleDef.nameTh}</h3>
          <p className={`text-sm mt-2 ${isGood ? 'text-blue-300' : 'text-red-300'}`}>
            {isGood ? 'ฝ่ายผู้ภักดี' : 'ฝ่ายลูกสมุน'}
          </p>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export const ControllerMode = ({
  roomId,
  publicBoard,
  players,
  currentPlayer,
  privateRole,
  playerId,
  onSelectTeam,
  onSubmitVote,
  onSubmitQuestCard,
  onSubmitAssassination,
  onSetReady,
}: ControllerModeProps) => {
  const [showRole, setShowRole] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<string[]>([]);
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [hasVoted, setHasVoted] = useState(false);
  const [hasSubmittedCard, setHasSubmittedCard] = useState(false);
  const [showAnimation, setShowAnimation] = useState(true);
  const [animationComplete, setAnimationComplete] = useState(false);

  // Reset states when phase changes
  useEffect(() => {
    setHasVoted(false);
    setHasSubmittedCard(false);
    setSelectedTeam([]);
    setSelectedTarget(null);
  }, [publicBoard?.phase, publicBoard?.round]);

  // Show animation on role-reveal phase
  useEffect(() => {
    if (publicBoard?.phase === 'role-reveal' && privateRole && showAnimation) {
      setAnimationComplete(false);
      const timer = setTimeout(() => {
        setShowAnimation(false);
        setAnimationComplete(true);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [publicBoard?.phase, privateRole, showAnimation]);

  if (!roomId || !publicBoard) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="bg-white/5 backdrop-blur-sm border-white/10">
          <CardContent className="p-6 text-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full mx-auto mb-4"
            />
            <p className="text-slate-400">กำลังเชื่อมต่อ...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!currentPlayer) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="bg-white/5 backdrop-blur-sm border-white/10">
          <CardContent className="p-6 text-center">
            <p className="text-slate-400">ไม่พบข้อมูลผู้เล่น</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { phase, round, currentTeam, leaderId, teamSize, voteStatus } = publicBoard;
  const isLeader = currentPlayer.id === leaderId;
  const isInTeam = currentTeam?.includes(playerId);
  const roleDef = privateRole && privateRole.role in ROLE_DEFINITIONS ? ROLE_DEFINITIONS[privateRole.role as keyof typeof ROLE_DEFINITIONS] : null;
  const isGood = privateRole?.team === 'good';
  const isEvil = privateRole?.team === 'evil';
  const isAssassin = privateRole?.role === 'assassin';

  // Render Role Reveal Phase
  const renderRoleReveal = () => {
    // Show animation first
    if (showAnimation && privateRole && !animationComplete) {
      return (
        <RoleRevealAnimation 
          finalRole={privateRole.role} 
          onComplete={() => setAnimationComplete(true)}
        />
      );
    }

    if (!privateRole || !roleDef) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full"
          />
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <h2 className="text-2xl font-bold text-center mb-2">บทบาทของคุณ</h2>
          <p className="text-slate-400 text-center mb-6">กดปุ่มเพื่อดูบทบาท</p>

          {/* Role Card with Toggle */}
          <motion.div
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowRole(!showRole)}
            className="cursor-pointer"
          >
            <Card 
              className={`
                mb-6 border-2 transition-all duration-500 relative overflow-hidden
                ${isGood ? 'border-blue-500/50' : 'border-red-500/50'}
                ${!showRole ? 'bg-slate-800/80' : isGood ? 'bg-blue-500/20' : 'bg-red-500/20'}
              `}
            >
              {/* Blur overlay */}
              <AnimatePresence>
                {!showRole && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 backdrop-blur-xl bg-slate-900/60 flex flex-col items-center justify-center z-10"
                  >
                    <Lock className="w-16 h-16 text-slate-400 mb-4" />
                    <p className="text-slate-400 text-lg">แตะเพื่อเปิดเผย</p>
                    <p className="text-slate-500 text-sm mt-2">(อย่าให้คนอื่นเห็น!)</p>
                  </motion.div>
                )}
              </AnimatePresence>

              <CardContent className="p-8 text-center">
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className={`
                    text-6xl mb-4
                    ${isGood ? 'text-blue-400' : 'text-red-400'}
                  `}>
                    {isGood ? <Shield className="w-20 h-20 mx-auto" /> : <Sword className="w-20 h-20 mx-auto" />}
                  </div>
                  <h3 className="text-3xl font-bold mb-2">{roleDef.nameTh}</h3>
                  <p className={`text-lg mb-4 ${isGood ? 'text-blue-300' : 'text-red-300'}`}>
                    {isGood ? 'ฝ่ายผู้ภักดี' : 'ฝ่ายลูกสมุน'}
                  </p>
                  <p className="text-slate-300">{roleDef.descriptionTh}</p>
                  
                  {privateRole.knownPlayers.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="mt-6 pt-4 border-t border-white/10"
                    >
                      <p className="text-sm text-slate-400 mb-3">คุณรู้จัก:</p>
                      <div className="flex flex-wrap justify-center gap-2">
                        {privateRole.knownPlayers.map((knownId) => {
                          const knownPlayer = players[knownId];
                          const knownRole = privateRole.knownRoles?.[knownId];
                          if (!knownPlayer) return null;
                          
                          return (
                            <Badge key={knownId} variant="secondary" className="bg-white/10 px-3 py-1">
                              {knownPlayer.name}
                              {knownRole && (
                                <span className="ml-1 text-xs opacity-70">
                                  ({ROLE_DEFINITIONS[knownRole]?.nameTh})
                                </span>
                              )}
                            </Badge>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Toggle hint */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-center text-slate-500 text-sm mb-6"
          >
            {showRole ? 'แตะการ์ดอีกครั้งเพื่อซ่อน' : 'แตะการ์ดเพื่อดูบทบาท'}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Button 
              onClick={onSetReady}
              className="w-full bg-gradient-to-r from-green-600 to-green-800 py-6 text-lg"
            >
              <Check className="w-5 h-5 mr-2" />
              พร้อมเล่น
            </Button>
          </motion.div>
        </motion.div>
      </div>
    );
  };

  // Render Team Selection Phase
  const renderTeamSelection = () => {
    if (!isLeader) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <Crown className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
            </motion.div>
            <h2 className="text-2xl font-bold mb-2">รอหัวหน้าเลือกทีม</h2>
            <p className="text-slate-400">
              หัวหน้า: <span className="text-yellow-400 font-medium">{players[leaderId]?.name}</span>
            </p>
            
            <AnimatePresence>
              {currentTeam?.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="mt-6 p-4 bg-white/5 rounded-xl"
                >
                  <p className="text-slate-400 mb-3">ทีมที่เสนอ:</p>
                  <div className="flex flex-wrap justify-center gap-2">
                    {currentTeam.map((pid: string) => (
                      <Badge key={pid} className="bg-blue-500/20 px-3 py-1">
                        {players[pid]?.name}
                      </Badge>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      );
    }

    const canConfirm = selectedTeam.length === teamSize;

    return (
      <div className="min-h-screen flex flex-col p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex-1"
        >
          <div className="text-center mb-6">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              <Crown className="w-12 h-12 mx-auto mb-2 text-yellow-400" />
            </motion.div>
            <h2 className="text-2xl font-bold">คุณเป็นหัวหน้า!</h2>
            <p className="text-slate-400 mt-1">
              เลือก <span className="text-white font-bold">{teamSize}</span> คน สำหรับภารกิจที่ {round + 1}
            </p>
          </div>

          <div className="space-y-2 mb-6">
            {Object.values(players).map((player, index) => {
              const isSelected = selectedTeam.includes(player.id);
              
              return (
                <motion.button
                  key={player.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    if (isSelected) {
                      setSelectedTeam(selectedTeam.filter(id => id !== player.id));
                    } else if (selectedTeam.length < teamSize) {
                      setSelectedTeam([...selectedTeam, player.id]);
                    }
                  }}
                  className={`
                    w-full p-4 rounded-xl border-2 flex items-center justify-between transition-all
                    ${isSelected 
                      ? 'bg-blue-500/30 border-blue-500 shadow-lg shadow-blue-500/20' 
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }
                  `}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-sm font-bold">
                      {player.name?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <span className="font-medium">{player.name || 'Unknown'}</span>
                  </div>
                  {isSelected && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                    >
                      <Check className="w-6 h-6 text-blue-400" />
                    </motion.div>
                  )}
                </motion.button>
              );
            })}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Button
              onClick={() => onSelectTeam(selectedTeam)}
              disabled={!canConfirm}
              className={`
                w-full py-6 text-lg transition-all
                ${canConfirm 
                  ? 'bg-gradient-to-r from-blue-600 to-blue-800' 
                  : 'bg-slate-700 cursor-not-allowed'
                }
              `}
            >
              <ChevronRight className="w-5 h-5 mr-2" />
              ยืนยันทีม ({selectedTeam.length}/{teamSize})
            </Button>
          </motion.div>
        </motion.div>
      </div>
    );
  };

  // Render Voting Phase
  const renderVoting = () => {
    if (hasVoted) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              <Check className="w-16 h-16 mx-auto mb-4 text-green-400" />
            </motion.div>
            <h2 className="text-2xl font-bold mb-2">โหวตแล้ว</h2>
            <p className="text-slate-400">รอผู้เล่นคนอื่น...</p>
            <div className="mt-4 inline-flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full">
              <span className="text-slate-400">โหวตแล้ว:</span>
              <span className="font-bold">{voteStatus?.casted || 0} / {voteStatus?.total || Object.keys(players).length}</span>
            </div>
          </motion.div>
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <h2 className="text-2xl font-bold text-center mb-2">โหวตรับรองทีม</h2>
          <p className="text-slate-400 text-center mb-6">คุณเห็นด้วยกับทีมนี้หรือไม่?</p>
          
          {currentTeam?.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6 p-4 bg-white/5 rounded-xl text-center"
            >
              <p className="text-slate-400 text-sm mb-2">ทีมที่เสนอ:</p>
              <div className="flex flex-wrap justify-center gap-2">
                {currentTeam.map((pid: string) => (
                  <Badge key={pid} className="bg-blue-500/20 px-3 py-1">
                    {players[pid]?.name}
                  </Badge>
                ))}
              </div>
            </motion.div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setHasVoted(true);
                onSubmitVote('approve');
              }}
              className="p-6 rounded-xl bg-green-500/20 border-2 border-green-500/50 hover:bg-green-500/30 transition-all"
            >
              <UserCheck className="w-12 h-12 mx-auto mb-2 text-green-400" />
              <span className="text-lg font-bold text-green-400">เห็นด้วย</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setHasVoted(true);
                onSubmitVote('reject');
              }}
              className="p-6 rounded-xl bg-red-500/20 border-2 border-red-500/50 hover:bg-red-500/30 transition-all"
            >
              <UserX className="w-12 h-12 mx-auto mb-2 text-red-400" />
              <span className="text-lg font-bold text-red-400">ไม่เห็นด้วย</span>
            </motion.button>
          </div>
        </motion.div>
      </div>
    );
  };

  // Render Quest Phase
  const renderQuest = () => {
    if (!isInTeam) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4"
            />
            <h2 className="text-xl font-bold mb-2">รอทีมทำภารกิจ</h2>
            <p className="text-slate-400">สมาชิกในทีมกำลังเลือกการ์ด...</p>
          </motion.div>
        </div>
      );
    }

    if (hasSubmittedCard) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              <Check className="w-16 h-16 mx-auto mb-4 text-green-400" />
            </motion.div>
            <h2 className="text-2xl font-bold mb-2">ส่งการ์ดแล้ว</h2>
            <p className="text-slate-400">รอสมาชิกคนอื่น...</p>
          </motion.div>
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <h2 className="text-2xl font-bold text-center mb-2">เลือกการ์ดภารกิจ</h2>
          <p className="text-slate-400 text-center mb-6">เลือกผลลัพธ์ของภารกิจนี้</p>

          <div className="grid grid-cols-2 gap-4">
            {/* Success Card */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setHasSubmittedCard(true);
                onSubmitQuestCard('success');
              }}
              className="p-6 rounded-xl bg-blue-500/20 border-2 border-blue-500/50 hover:bg-blue-500/30 transition-all"
            >
              <Check className="w-12 h-12 mx-auto mb-2 text-blue-400" />
              <span className="text-lg font-bold text-blue-400">สำเร็จ</span>
              <p className="text-xs text-slate-400 mt-2">ช่วยฝ่าย Good</p>
            </motion.button>

            {/* Fail Card */}
            <motion.button
              whileHover={{ scale: isGood ? 1 : 1.02 }}
              whileTap={{ scale: isGood ? 1 : 0.95 }}
              onClick={() => {
                if (!isGood) {
                  setHasSubmittedCard(true);
                  onSubmitQuestCard('fail');
                }
              }}
              disabled={isGood}
              className={`
                p-6 rounded-xl border-2 transition-all
                ${isGood 
                  ? 'bg-slate-800/50 border-slate-700 opacity-50 cursor-not-allowed' 
                  : 'bg-red-500/20 border-red-500/50 hover:bg-red-500/30'
                }
              `}
            >
              <X className="w-12 h-12 mx-auto mb-2 text-red-400" />
              <span className="text-lg font-bold text-red-400">ล้มเหลว</span>
              {isGood ? (
                <p className="text-xs text-slate-500 mt-2">ฝ่าย Good ไม่สามารถเลือกได้</p>
              ) : (
                <p className="text-xs text-slate-400 mt-2">ช่วยฝ่าย Evil</p>
              )}
            </motion.button>
          </div>
        </motion.div>
      </div>
    );
  };

  // Render Quest Result Phase
  const renderQuestResult = () => {
    const { questResults, round } = publicBoard;
    const result = questResults[round];
    const failCount = publicBoard.questStatus?.failCount || 0;

    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: "spring", duration: 0.5 }}
          className="text-center"
        >
          {result === 'success' ? (
            <>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.2 }}
                className="w-24 h-24 mx-auto mb-4 rounded-full bg-blue-500/30 flex items-center justify-center border-4 border-blue-500"
              >
                <Check className="w-12 h-12 text-blue-400" />
              </motion.div>
              <h2 className="text-3xl font-bold text-blue-400 mb-2">ภารกิจสำเร็จ!</h2>
              <p className="text-slate-400">ทุกคนเลือก Success</p>
            </>
          ) : (
            <>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.2 }}
                className="w-24 h-24 mx-auto mb-4 rounded-full bg-red-500/30 flex items-center justify-center border-4 border-red-500"
              >
                <X className="w-12 h-12 text-red-400" />
              </motion.div>
              <h2 className="text-3xl font-bold text-red-400 mb-2">ภารกิจล้มเหลว!</h2>
              <p className="text-slate-400">พบ Fail {failCount} ใบ</p>
            </>
          )}
        </motion.div>
      </div>
    );
  };

  // Render Assassination Phase
  const renderAssassination = () => {
    if (!isEvil) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <Skull className="w-16 h-16 mx-auto mb-4 text-red-400" />
            </motion.div>
            <h2 className="text-2xl font-bold mb-2">รอการลอบสังหาร</h2>
            <p className="text-slate-400">ฝ่าย Evil กำลังเลือกเป้าหมาย...</p>
          </motion.div>
        </div>
      );
    }

    if (!isAssassin) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <Skull className="w-16 h-16 mx-auto mb-4 text-red-400" />
            </motion.div>
            <h2 className="text-2xl font-bold mb-2">รอมือสังหาร</h2>
            <p className="text-slate-400">มือสังหารกำลังเลือกเป้าหมาย...</p>
          </motion.div>
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex-1"
        >
          <div className="text-center mb-6">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              <Skull className="w-12 h-12 mx-auto mb-2 text-red-400" />
            </motion.div>
            <h2 className="text-2xl font-bold">เลือกเป้าหมาย</h2>
            <p className="text-slate-400 mt-1">เลือกคนที่คุณคิดว่าเป็น Merlin</p>
          </div>

          <div className="space-y-2 mb-6">
            {Object.values(players).map((player, index) => {
              if (player.id === playerId) return null;
              
              const isSelected = selectedTarget === player.id;
              
              return (
                <motion.button
                  key={player.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedTarget(player.id)}
                  className={`
                    w-full p-4 rounded-xl border-2 flex items-center justify-between transition-all
                    ${isSelected 
                      ? 'bg-red-500/30 border-red-500 shadow-lg shadow-red-500/20' 
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }
                  `}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-sm font-bold">
                      {player.name?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <span className="font-medium">{player.name || 'Unknown'}</span>
                  </div>
                  {isSelected && <Skull className="w-5 h-5 text-red-400" />}
                </motion.button>
              );
            })}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Button
              onClick={() => selectedTarget && onSubmitAssassination(selectedTarget)}
              disabled={!selectedTarget}
              className={`
                w-full py-6 text-lg transition-all
                ${selectedTarget 
                  ? 'bg-gradient-to-r from-red-600 to-red-800' 
                  : 'bg-slate-700 cursor-not-allowed'
                }
              `}
            >
              <Skull className="w-5 h-5 mr-2" />
              สังหาร
            </Button>
          </motion.div>
        </motion.div>
      </div>
    );
  };

  // Render Game End
  const renderGameEnd = () => {
    const winner = publicBoard?.winner;
    const isGoodWin = winner === 'good';

    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", duration: 0.8 }}
          >
            {isGoodWin ? (
              <>
                <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-blue-500/30 flex items-center justify-center border-4 border-blue-500">
                  <Check className="w-16 h-16 text-blue-400" />
                </div>
                <h2 className="text-4xl font-bold text-blue-400 mb-4">GOOD WINS!</h2>
              </>
            ) : (
              <>
                <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-red-500/30 flex items-center justify-center border-4 border-red-500">
                  <Skull className="w-16 h-16 text-red-400" />
                </div>
                <h2 className="text-4xl font-bold text-red-400 mb-4">EVIL WINS!</h2>
              </>
            )}
          </motion.div>
          
          {privateRole && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-6 p-4 bg-white/5 rounded-xl"
            >
              <p className="text-slate-400 text-sm mb-2">บทบาทของคุณ</p>
              <p className={`text-2xl font-bold ${privateRole.team === 'good' ? 'text-blue-400' : 'text-red-400'}`}>
                {ROLE_DEFINITIONS[privateRole.role]?.nameTh}
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    );
  };

  // Main render based on phase
  switch (phase) {
    case 'role-reveal':
      return renderRoleReveal();
    case 'team-selection':
      return renderTeamSelection();
    case 'voting':
      return renderVoting();
    case 'quest':
      return renderQuest();
    case 'quest-result':
      return renderQuestResult();
    case 'assassination':
      return renderAssassination();
    case 'game-end':
      return renderGameEnd();
    default:
      return (
        <div className="min-h-screen flex items-center justify-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full"
          />
        </div>
      );
  }
};

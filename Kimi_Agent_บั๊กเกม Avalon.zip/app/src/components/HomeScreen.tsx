// Home Screen Component
import { Crown, Smartphone, Users, Sword, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';

interface HomeScreenProps {
  onCreateRoom: () => void;
  onJoinRoom: () => void;
}

export const HomeScreen = ({ onCreateRoom, onJoinRoom }: HomeScreenProps) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 text-center max-w-2xl"
      >
        {/* Title */}
        <div className="mb-8">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring' }}
            className="flex items-center justify-center gap-4 mb-4"
          >
            <Shield className="w-12 h-12 text-blue-400" />
            <Sword className="w-12 h-12 text-red-400" />
          </motion.div>
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-yellow-400 via-purple-400 to-blue-400 bg-clip-text text-transparent mb-2">
            AVALON
          </h1>
          <p className="text-xl text-purple-200">The Resistance</p>
          <p className="text-sm text-slate-400 mt-2">ระบบช่วยเล่นเกมแบบ Real-time</p>
        </div>

        {/* Description */}
        <Card className="bg-white/5 backdrop-blur-sm border-white/10 mb-8">
          <CardContent className="p-6">
            <p className="text-slate-300 leading-relaxed">
              เกมกลยุทธ์สืบหาผู้ทรยศในตำนานกษัตริย์อาร์เธอร์ 
              ผู้เล่นฝ่าย <span className="text-blue-400 font-semibold">Good</span> ต้องทำภารกิจให้สำเร็จ 
              ส่วนฝ่าย <span className="text-red-400 font-semibold">Evil</span> ต้องหยุดยั้งและหลอกลวง
            </p>
          </CardContent>
        </Card>

        {/* Mode Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={onCreateRoom}
              className="w-full h-32 bg-gradient-to-br from-purple-600 to-purple-800 hover:from-purple-500 hover:to-purple-700 border-0 text-lg font-semibold flex flex-col items-center gap-3"
            >
              <Crown className="w-8 h-8" />
              <div>
                <div>สร้างห้อง (TV Mode)</div>
                <div className="text-xs text-purple-200 font-normal">สำหรับแท็บเล็ต/จอใหญ่</div>
              </div>
            </Button>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={onJoinRoom}
              className="w-full h-32 bg-gradient-to-br from-blue-600 to-blue-800 hover:from-blue-500 hover:to-blue-700 border-0 text-lg font-semibold flex flex-col items-center gap-3"
            >
              <Smartphone className="w-8 h-8" />
              <div>
                <div>เข้าร่วม (Controller)</div>
                <div className="text-xs text-blue-200 font-normal">สำหรับมือถือผู้เล่น</div>
              </div>
            </Button>
          </motion.div>
        </div>

        {/* Player Count Info */}
        <div className="mt-8 flex items-center justify-center gap-2 text-slate-400">
          <Users className="w-4 h-4" />
          <span className="text-sm">รองรับ 5-10 ผู้เล่น</span>
        </div>
      </motion.div>
    </div>
  );
};

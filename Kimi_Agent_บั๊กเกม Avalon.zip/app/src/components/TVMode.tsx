// TV Mode Component - Public Display for Avalon
import { useState } from 'react';
import { Crown, Users, Play, RotateCcw, Check, X, Skull, Trophy, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { QRCodeSVG } from 'qrcode.react';
import type { GameState, Player } from '@/types';
import { ROLE_DEFINITIONS, TRANSLATIONS_TH, TEAM_SIZES } from '@/types';

interface TVModeProps {
  roomId: string | null;
  gameState: GameState | null;
  publicBoard: any;
  players: Player[];
  onCreateRoom: (playerCount: number) => void;
  onStartGame: () => void;
  onNextRound: () => void;
  onResetGame: () => void;
  onCancel: () => void;
  loading: boolean;
}

export const TVMode = ({
  roomId,
  gameState,
  publicBoard,
  players,
  onCreateRoom,
  onStartGame,
  onResetGame,
  onCancel,
  loading,
}: TVModeProps) => {
  const [selectedPlayerCount, setSelectedPlayerCount] = useState(7);

  // Get current URL for QR code
  const getJoinUrl = () => {
    if (typeof window === 'undefined') return '';
    return `${window.location.origin}?room=${roomId}`;
  };

  // Render Lobby (Waiting Room)
  const renderLobby = () => {
    if (!roomId) {
      // Room creation screen
      return (
        <div className="flex flex-col items-center justify-center min-h-screen p-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <h2 className="text-3xl font-bold mb-2">สร้างห้องใหม่</h2>
            <p className="text-slate-400 mb-8">เลือกจำนวนผู้เล่น</p>
            
            <div className="flex gap-3 mb-8 flex-wrap justify-center">
              {[5, 6, 7, 8, 9, 10].map((count) => (
                <motion.button
                  key={count}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedPlayerCount(count)}
                  className={`
                    w-14 h-14 text-xl font-bold rounded-xl transition-all
                    ${selectedPlayerCount === count 
                      ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30' 
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                    }
                  `}
                >
                  {count}
                </motion.button>
              ))}
            </div>

            {/* Role distribution info */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="mb-8 p-4 bg-white/5 rounded-xl"
            >
              <p className="text-sm text-slate-400 mb-2">การแบ่งทีม</p>
              <div className="flex justify-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-blue-400">
                    Good {Math.ceil(selectedPlayerCount * 0.6)}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <span className="text-red-400">
                    Evil {Math.floor(selectedPlayerCount * 0.4)}
                  </span>
                </div>
              </div>
            </motion.div>

            <div className="flex gap-3 justify-center">
              <Button
                variant="outline"
                onClick={onCancel}
                className="px-6 py-5 border-white/20 hover:bg-white/10"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                ยกเลิก
              </Button>
              <Button
                onClick={() => onCreateRoom(selectedPlayerCount)}
                className="px-8 py-5 text-lg bg-gradient-to-r from-purple-600 to-purple-800"
                disabled={loading}
              >
                <Crown className="w-5 h-5 mr-2" />
                สร้างห้อง
              </Button>
            </div>
          </motion.div>
        </div>
      );
    }

    // Waiting room with QR code
    const maxPlayers = gameState?.meta.config.playerCount || selectedPlayerCount;
    const isReady = players.length >= 5;

    return (
      <div className="min-h-screen flex flex-col p-4 md:p-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-6"
        >
          <div>
            <h1 className="text-2xl font-bold">ห้องรอผู้เล่น</h1>
            <p className="text-slate-400 text-sm">รอผู้เล่นเข้าร่วม...</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onCancel}
            className="text-slate-400 hover:text-red-400"
          >
            ปิดห้อง
          </Button>
        </motion.div>

        <div className="flex-1 flex flex-col lg:flex-row gap-6 items-start justify-center">
          {/* Left: QR Code & Room Code */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="flex flex-col items-center"
          >
            <Card className="bg-white p-4 rounded-xl mb-4">
              <QRCodeSVG value={getJoinUrl()} size={180} />
            </Card>
            
            <div className="text-center">
              <p className="text-slate-400 text-sm mb-1">รหัสห้อง</p>
              <div className="text-4xl font-bold tracking-widest bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                {roomId}
              </div>
            </div>

            <p className="text-slate-500 text-sm mt-4 text-center max-w-[200px]">
              ให้ผู้เล่นสแกน QR Code หรือกรอกรหัสห้อง
            </p>
          </motion.div>

          {/* Right: Player List */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="flex-1 max-w-md w-full"
          >
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-purple-400" />
                    <span className="font-medium">ผู้เล่น</span>
                  </div>
                  <Badge variant="secondary" className="bg-white/10">
                    {players.length} / {maxPlayers}
                  </Badge>
                </div>

                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  <AnimatePresence mode="popLayout">
                    {players.map((player, index) => (
                      <motion.div
                        key={player.id}
                        layout
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-center gap-3 p-3 bg-white/5 rounded-lg"
                      >
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-sm font-bold">
                          {player.name?.charAt(0).toUpperCase() || '?'}
                        </div>
                        <span className="font-medium">{player.name || 'Unknown'}</span>
                        <div className="ml-auto w-2 h-2 rounded-full bg-green-500" />
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {players.length === 0 && (
                    <div className="text-center py-8 text-slate-500">
                      <p>ยังไม่มีผู้เล่นเข้าร่วม</p>
                      <p className="text-sm">รอผู้เล่นสแกน QR Code...</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Start Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-4"
            >
              <Button
                onClick={onStartGame}
                className="w-full py-6 text-lg bg-gradient-to-r from-green-600 to-green-800"
                disabled={!isReady || loading}
              >
                <Play className="w-5 h-5 mr-2" />
                {isReady ? 'เริ่มเกม' : `ต้องการอีก ${5 - players.length} คน`}
              </Button>
              
              {!isReady && (
                <p className="text-center text-slate-500 text-sm mt-2">
                  ต้องมีอย่างน้อย 5 ผู้เล่นจึงจะเริ่มเกมได้
                </p>
              )}
            </motion.div>
          </motion.div>
        </div>
      </div>
    );
  };

  // Render Game Board
  const renderGameBoard = () => {
    if (!publicBoard) return null;

    const { phase, round, questResults, currentTeam, leaderId } = publicBoard;
    const leader = players.find(p => p.id === leaderId);
    const successCount = questResults.filter((r: any) => r === 'success').length;
    const failCount = questResults.filter((r: any) => r === 'fail').length;

    return (
      <div className="min-h-screen p-4 md:p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-6"
        >
          <div className="flex items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold">AVALON</h1>
              <p className="text-slate-400 text-sm">ห้อง {roomId}</p>
            </div>
          </div>
          
          {/* Score */}
          <div className="flex gap-3">
            <div className="bg-blue-500/20 px-4 py-2 rounded-lg border border-blue-500/30">
              <span className="text-blue-400 text-sm">Good</span>
              <span className="text-xl font-bold ml-2">{successCount}</span>
            </div>
            <div className="bg-red-500/20 px-4 py-2 rounded-lg border border-red-500/30">
              <span className="text-red-400 text-sm">Evil</span>
              <span className="text-xl font-bold ml-2">{failCount}</span>
            </div>
          </div>
        </motion.div>

        {/* Quest Track */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <div className="flex justify-center gap-2">
            {[0, 1, 2, 3, 4].map((questIndex) => {
              const result = questResults[questIndex];
              const isCurrent = questIndex === round;
              const teamSize = gameState ? TEAM_SIZES[players.length]?.[questIndex] : 0;
              const requiresTwoFails = questIndex === 3 && players.length >= 7;
              
              return (
                <motion.div
                  key={questIndex}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: questIndex * 0.1 }}
                  className={`
                    relative w-14 h-20 md:w-20 md:h-24 rounded-xl flex flex-col items-center justify-center
                    ${result === 'success' ? 'bg-blue-500/40 border-2 border-blue-500' : ''}
                    ${result === 'fail' ? 'bg-red-500/40 border-2 border-red-500' : ''}
                    ${!result && isCurrent ? 'bg-purple-500/40 border-2 border-purple-500 ring-2 ring-purple-500/50' : ''}
                    ${!result && !isCurrent ? 'bg-white/5 border-2 border-white/10' : ''}
                  `}
                >
                  <span className="text-xs text-slate-400">Q{questIndex + 1}</span>
                  <span className="text-lg md:text-xl font-bold">{teamSize || '?'}</span>
                  {requiresTwoFails && !result && (
                    <span className="text-[8px] text-yellow-400 absolute -top-1">x2</span>
                  )}
                  {result === 'success' && <Check className="w-5 h-5 text-blue-400" />}
                  {result === 'fail' && <X className="w-5 h-5 text-red-400" />}
                  {isCurrent && !result && (
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                    >
                      <Crown className="w-4 h-4 text-purple-400" />
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Phase Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-6"
        >
          <Badge className="px-4 py-2 text-base bg-purple-500/20 border-purple-500/50">
            {TRANSLATIONS_TH[`phase.${phase}`] || phase}
          </Badge>
          
          {leader && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-3 text-lg"
            >
              <Crown className="inline w-5 h-5 mr-2 text-yellow-400" />
              หัวหน้า: <span className="font-bold">{leader.name}</span>
            </motion.p>
          )}
        </motion.div>

        {/* Current Team */}
        <AnimatePresence>
          {currentTeam?.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-6"
            >
              <h3 className="text-center text-slate-400 text-sm mb-3">ทีมปัจจุบัน</h3>
              <div className="flex justify-center gap-2 flex-wrap">
                {currentTeam.map((playerId: string, index: number) => {
                  const player = players.find(p => p.id === playerId);
                  if (!player) return null;
                  
                  return (
                    <motion.div
                      key={playerId}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Badge className="px-3 py-2 text-base bg-blue-500/20 border-blue-500/50">
                        {player.name}
                      </Badge>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Player Circle */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="relative w-full max-w-lg mx-auto aspect-square max-h-[400px]"
        >
          {/* Center */}
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
              className="w-28 h-28 md:w-36 md:h-36 rounded-full bg-gradient-to-br from-purple-500/30 via-blue-500/20 to-purple-500/30 flex items-center justify-center border-2 border-white/10"
            >
              <span className="text-4xl md:text-5xl font-bold">
                {round + 1}
              </span>
            </motion.div>
          </div>
          
          {/* Players */}
          {players.map((player, index) => {
            const angle = (index / players.length) * 2 * Math.PI - Math.PI / 2;
            const radius = 38;
            const x = 50 + radius * Math.cos(angle);
            const y = 50 + radius * Math.sin(angle);
            const isLeader = player.id === leaderId;
            const isInTeam = currentTeam?.includes(player.id);
            
            return (
              <motion.div
                key={player.id}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 + index * 0.05 }}
                className="absolute transform -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${x}%`, top: `${y}%` }}
              >
                <div className={`
                  relative px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap
                  transition-all duration-300
                  ${isLeader ? 'bg-yellow-500/40 border-2 border-yellow-500 text-yellow-100' : 'bg-white/10 border border-white/20'}
                  ${isInTeam ? 'ring-2 ring-blue-500 scale-110' : ''}
                `}>
                  {isLeader && (
                    <Crown className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-4 h-4 text-yellow-400" />
                  )}
                  {player.name || 'Unknown'}
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Logs */}
        {publicBoard.logs?.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-6 max-w-xl mx-auto"
          >
            <h3 className="text-slate-400 text-sm mb-2 text-center">ประวัติเกม</h3>
            <div className="bg-black/30 rounded-lg p-3 max-h-28 overflow-y-auto">
              {publicBoard.logs.slice(-5).reverse().map((log: any) => (
                <div key={log.id} className="text-sm mb-1">
                  <span className={`
                    ${log.type === 'success' ? 'text-green-400' : ''}
                    ${log.type === 'fail' ? 'text-red-400' : ''}
                    ${log.type === 'warning' ? 'text-yellow-400' : ''}
                    ${!log.type || log.type === 'info' ? 'text-slate-300' : ''}
                  `}>
                    {log.message}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    );
  };

  // Render Game End
  const renderGameEnd = () => {
    if (!publicBoard?.winner) return null;

    const isGoodWin = publicBoard.winner === 'good';
    const allRoles = gameState?.privateRoles || {};

    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          {/* Winner Announcement */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", duration: 0.8 }}
            className={`
              text-5xl md:text-7xl font-bold mb-8
              ${isGoodWin ? 'text-blue-400' : 'text-red-400'}
            `}
          >
            {isGoodWin ? (
              <>
                <Trophy className="inline w-14 h-14 md:w-20 md:h-20 mb-4" />
                <div>GOOD WINS!</div>
              </>
            ) : (
              <>
                <Skull className="inline w-14 h-14 md:w-20 md:h-20 mb-4" />
                <div>EVIL WINS!</div>
              </>
            )}
          </motion.div>

          {/* Role Reveal */}
          <Card className="bg-white/5 backdrop-blur-sm border-white/10 mb-8 max-w-2xl">
            <CardContent className="p-6">
              <h3 className="text-xl mb-4">เผยโฉมบทบาท</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {players.map((player) => {
                  const role = allRoles[player.id]?.role;
                  const roleDef = role && role in ROLE_DEFINITIONS ? ROLE_DEFINITIONS[role as keyof typeof ROLE_DEFINITIONS] : null;
                  const isGood = roleDef?.team === 'good';
                  
                  return (
                    <motion.div
                      key={player.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`
                        p-3 rounded-lg border
                        ${isGood ? 'bg-blue-500/20 border-blue-500/30' : 'bg-red-500/20 border-red-500/30'}
                      `}
                    >
                      <div className="font-medium">{player.name}</div>
                      <div className={`text-sm ${isGood ? 'text-blue-300' : 'text-red-300'}`}>
                        {roleDef?.nameTh || role}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Play Again Button */}
          <Button
            onClick={onResetGame}
            className="px-8 py-6 text-xl bg-gradient-to-r from-purple-600 to-purple-800"
          >
            <RotateCcw className="w-6 h-6 mr-3" />
            เล่นใหม่
          </Button>
        </motion.div>
      </div>
    );
  };

  // Main render
  if (!publicBoard) {
    return renderLobby();
  }

  switch (publicBoard.phase) {
    case 'lobby':
      return renderLobby();
    case 'game-end':
      return renderGameEnd();
    default:
      return renderGameBoard();
  }
};

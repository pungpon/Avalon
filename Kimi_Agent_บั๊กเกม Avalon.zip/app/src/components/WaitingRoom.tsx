// Waiting Room Component - Shows while waiting for game to start
import { useState } from 'react';
import { Users, LogOut, BookOpen, ChevronDown, ChevronUp, Shield, Sword } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { ROLE_DEFINITIONS } from '@/types';
import type { Player } from '@/types';

interface WaitingRoomProps {
  roomId: string | null;
  players: Player[];
  currentPlayer: Player | null;
  maxPlayers: number;
  onLeave: () => void;
}

export const WaitingRoom = ({ roomId, players, currentPlayer, maxPlayers, onLeave }: WaitingRoomProps) => {
  const [showRoleGuide, setShowRoleGuide] = useState(false);

  // Get all unique roles for display
  const allRoles = Object.values(ROLE_DEFINITIONS);
  const goodRoles = allRoles.filter(r => r.team === 'good');
  const evilRoles = allRoles.filter(r => r.team === 'evil');

  return (
    <div className="min-h-screen flex flex-col p-4">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center mb-6"
      >
        <div>
          <h1 className="text-2xl font-bold">ห้องรอ</h1>
          {roomId && (
            <p className="text-slate-400 text-sm">รหัสห้อง: <span className="text-yellow-400 font-mono">{roomId}</span></p>
          )}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onLeave}
          className="text-slate-400 hover:text-red-400"
        >
          <LogOut className="w-4 h-4 mr-2" />
          ออก
        </Button>
      </motion.div>

      {/* Player Count */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="text-center mb-6"
      >
        <div className="inline-flex items-center gap-3 bg-white/5 px-6 py-3 rounded-full">
          <Users className="w-5 h-5 text-purple-400" />
          <span className="text-xl">
            <span className="font-bold text-white">{players.length}</span>
            <span className="text-slate-400"> / {maxPlayers} ผู้เล่น</span>
          </span>
        </div>
      </motion.div>

      {/* Players List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex-1 mb-6"
      >
        <h3 className="text-slate-400 text-sm mb-3 text-center">ผู้เล่นที่เข้าร่วม</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <AnimatePresence mode="popLayout">
            {players.map((player, index) => (
              <motion.div
                key={player.id}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className={`
                  bg-white/5 border-white/10
                  ${player.id === currentPlayer?.id ? 'ring-2 ring-purple-500/50' : ''}
                `}>
                  <CardContent className="p-3 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-sm font-bold">
                      {player.name?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <span className="font-medium truncate">{player.name}</span>
                    {player.id === currentPlayer?.id && (
                      <Badge variant="secondary" className="ml-auto text-xs bg-purple-500/20">
                        คุณ
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {/* Empty slots */}
          {Array.from({ length: Math.max(0, maxPlayers - players.length) }).map((_, i) => (
            <motion.div
              key={`empty-${i}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 + i * 0.05 }}
            >
              <Card className="bg-white/5 border-white/5 border-dashed">
                <CardContent className="p-3 flex items-center justify-center text-slate-500">
                  <span className="text-sm">รอผู้เล่น...</span>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Role Guide Toggle */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <Button
          variant="outline"
          onClick={() => setShowRoleGuide(!showRoleGuide)}
          className="w-full mb-4 border-white/20 hover:bg-white/5"
        >
          <BookOpen className="w-4 h-4 mr-2" />
          {showRoleGuide ? 'ซ่อน' : 'แสดง'}คู่มือบทบาท
          {showRoleGuide ? <ChevronUp className="w-4 h-4 ml-2" /> : <ChevronDown className="w-4 h-4 ml-2" />}
        </Button>

        <AnimatePresence>
          {showRoleGuide && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <Card className="bg-white/5 border-white/10 mb-4">
                <CardContent className="p-4">
                  <h4 className="text-sm text-slate-400 mb-3">บทบาทในเกม</h4>
                  
                  {/* Good Roles */}
                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="w-4 h-4 text-blue-400" />
                      <span className="text-sm font-medium text-blue-400">ฝ่ายผู้ภักดี (Good)</span>
                    </div>
                    <div className="space-y-2">
                      {goodRoles.slice(0, 4).map((role) => (
                        <div key={role.id} className="text-xs bg-blue-500/10 p-2 rounded">
                          <span className="font-medium text-blue-300">{role.nameTh}</span>
                          <span className="text-slate-400 ml-2">{role.descriptionTh}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Evil Roles */}
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Sword className="w-4 h-4 text-red-400" />
                      <span className="text-sm font-medium text-red-400">ฝ่ายลูกสมุน (Evil)</span>
                    </div>
                    <div className="space-y-2">
                      {evilRoles.slice(0, 4).map((role) => (
                        <div key={role.id} className="text-xs bg-red-500/10 p-2 rounded">
                          <span className="font-medium text-red-300">{role.nameTh}</span>
                          <span className="text-slate-400 ml-2">{role.descriptionTh}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Waiting Message */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-center py-4"
      >
        <div className="flex items-center justify-center gap-2 text-slate-400">
          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          <span className="ml-2">รอ Host เริ่มเกม...</span>
        </div>
      </motion.div>
    </div>
  );
};

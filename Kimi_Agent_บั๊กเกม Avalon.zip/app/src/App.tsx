// Main App Component for Avalon Digital Board Game
import { useState, useEffect } from 'react';
import { useGame } from '@/hooks/useGame';
import { TVMode } from '@/components/TVMode';
import { ControllerMode } from '@/components/ControllerMode';
import { HomeScreen } from '@/components/HomeScreen';
import { JoinRoom } from '@/components/JoinRoom';
import { WaitingRoom } from '@/components/WaitingRoom';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

type AppView = 'home' | 'join' | 'tv' | 'controller' | 'waiting';

function App() {
  const [view, setView] = useState<AppView>('home');
  const [joinError, setJoinError] = useState<string | null>(null);
  const [preFillRoomCode, setPreFillRoomCode] = useState<string>('');
  
  const {
    roomId,
    gameState,
    publicBoard,
    players,
    privateRole,
    currentPlayer,
    playerId,
    loading,
    error,
    createNewRoom,
    joinExistingRoom,
    startGame,
    selectTeam,
    submitVote,
    submitQuestCard,
    submitAssassination,
    nextRound,
    resetGame,
    setPlayerReady,
    setOnline,
    clearError,
    leaveRoom,
  } = useGame();

  // Check for room code in URL on mount
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const roomFromUrl = urlParams.get('room');
    if (roomFromUrl) {
      setPreFillRoomCode(roomFromUrl.toUpperCase());
      setView('join');
    }
  }, []);

  // Handle errors
  useEffect(() => {
    if (error) {
      toast.error(error);
      clearError();
    }
  }, [error, clearError]);

  // Set online status
  useEffect(() => {
    if (roomId) {
      setOnline(true);
      
      const handleBeforeUnload = () => {
        setOnline(false);
      };
      
      window.addEventListener('beforeunload', handleBeforeUnload);
      
      return () => {
        window.removeEventListener('beforeunload', handleBeforeUnload);
        setOnline(false);
      };
    }
  }, [roomId, setOnline]);

  // Watch for game phase changes
  useEffect(() => {
    if (publicBoard?.phase === 'role-reveal' && view === 'waiting') {
      setView('controller');
    }
  }, [publicBoard?.phase, view]);

  // Create room (TV Mode)
  const handleCreateRoom = async (playerCount: number) => {
    try {
      await createNewRoom(playerCount);
      setView('tv');
    } catch (err) {
      toast.error('Failed to create room');
    }
  };

  // Join room
  const handleJoinRoom = async (roomCode: string, playerName: string) => {
    try {
      setJoinError(null);
      await joinExistingRoom(roomCode, playerName);
      setView('waiting');
    } catch (err) {
      setJoinError('Invalid room code or failed to join');
      toast.error('Failed to join room');
    }
  };

  // Handle leave room
  const handleLeaveRoom = () => {
    leaveRoom();
    setView('home');
  };

  // Render current view
  const renderView = () => {
    console.log('Current view:', view, 'roomId:', roomId, 'publicBoard:', publicBoard?.phase);
    
    switch (view) {
      case 'home':
        return (
          <HomeScreen 
            onCreateRoom={() => setView('tv')} 
            onJoinRoom={() => setView('join')}
          />
        );
        
      case 'join':
        return (
          <JoinRoom 
            onJoin={handleJoinRoom}
            onBack={() => setView('home')}
            error={joinError}
            loading={loading}
            preFillRoomCode={preFillRoomCode}
          />
        );
        
      case 'waiting':
        return (
          <WaitingRoom
            roomId={roomId}
            players={Object.values(players)}
            currentPlayer={currentPlayer}
            maxPlayers={gameState?.meta.config.playerCount || 7}
            onLeave={handleLeaveRoom}
          />
        );
        
      case 'tv':
        if (!roomId) {
          return (
            <TVMode
              roomId={null}
              gameState={null}
              publicBoard={null}
              players={[]}
              onCreateRoom={handleCreateRoom}
              onStartGame={startGame}
              onNextRound={nextRound}
              onResetGame={resetGame}
              loading={loading}
              onCancel={() => setView('home')}
            />
          );
        }
        
        return (
          <TVMode
            roomId={roomId}
            gameState={gameState}
            publicBoard={publicBoard}
            players={Object.values(players)}
            onCreateRoom={handleCreateRoom}
            onStartGame={startGame}
            onNextRound={nextRound}
            onResetGame={resetGame}
            loading={loading}
            onCancel={() => setView('home')}
          />
        );
        
      case 'controller':
        return (
          <ControllerMode
            roomId={roomId}
            publicBoard={publicBoard}
            players={players}
            currentPlayer={currentPlayer}
            privateRole={privateRole}
            playerId={playerId}
            onSelectTeam={selectTeam}
            onSubmitVote={submitVote}
            onSubmitQuestCard={submitQuestCard}
            onSubmitAssassination={submitAssassination}
            onSetReady={setPlayerReady}
          />
        );
        
      default:
        return <HomeScreen onCreateRoom={() => setView('tv')} onJoinRoom={() => setView('join')} />;
    }
  };

  return (
    <ErrorBoundary onReset={() => setView('home')}>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
        {renderView()}
        <Toaster position="top-center" richColors />
      </div>
    </ErrorBoundary>
  );
}

export default App;

// Avalon Digital Board Game - TypeScript Types
// Based on avalon-game.com/wiki/rules/

// ==================== ENUMS ====================

export type GamePhase = 
  | 'lobby' 
  | 'role-reveal' 
  | 'team-selection' 
  | 'voting' 
  | 'quest' 
  | 'quest-result' 
  | 'assassination' 
  | 'game-end';

export type GameStatus = 'waiting' | 'playing' | 'ended';

export type Role = 
  | 'merlin' 
  | 'percival' 
  | 'tristan' 
  | 'isolde' 
  | 'loyal' 
  | 'assassin' 
  | 'morgana' 
  | 'mordred' 
  | 'oberon' 
  | 'minion';

export type Team = 'good' | 'evil';

export type QuestResult = 'success' | 'fail' | null;

export type VoteValue = 'approve' | 'reject';

export type QuestCard = 'success' | 'fail';

// ==================== PLAYER ====================

export interface Player {
  id: string;
  name: string;
  seatIndex: number;
  isOnline: boolean;
  isLeader: boolean;
  joinedAt: number;
}

export interface PlayerWithRole extends Player {
  role: Role;
  team: Team;
}

// ==================== ROOM METADATA ====================

export interface RoomConfig {
  playerCount: number;
  roles: Role[];
  useExcalibur: boolean;
  language: 'th' | 'en';
}

export interface RoomMeta {
  hostDeviceId: string;
  status: GameStatus;
  createdAt: number;
  config: RoomConfig;
}

// ==================== PUBLIC BOARD ====================

export interface VoteStatus {
  total: number;
  casted: number;
  revealed: boolean;
  approveCount: number;
  rejectCount: number;
  votes?: Record<string, VoteValue>; // Only visible after revealed
}

export interface QuestStatus {
  submitted: number;
  required: number;
  failCount: number;
  cards?: Record<string, QuestCard>; // Only visible after quest ends
}

export interface PublicBoard {
  phase: GamePhase;
  round: number; // 0-4 (5 quests)
  leaderId: string | null;
  questResults: QuestResult[]; // Array of 5
  currentTeam: string[]; // Array of playerIds
  teamSize: number;
  voteStatus: VoteStatus;
  questStatus: QuestStatus;
  winner: Team | null;
  logs: GameLog[];
  rejectedTeamsCount: number; // Track consecutive rejections
  assassinationTarget: string | null;
}

export interface GameLog {
  id: string;
  timestamp: number;
  message: string;
  type: 'info' | 'success' | 'fail' | 'warning';
}

// ==================== PRIVATE DATA ====================

export interface PrivateRole {
  role: Role;
  team: Team;
  knownPlayers: string[]; // IDs of players this role knows about
  knownRoles?: Record<string, Role>; // For Merlin/Percival to know specific roles
}

export interface SecretVote {
  playerId: string;
  vote: VoteValue;
  timestamp: number;
}

export interface QuestCardSubmission {
  playerId: string;
  card: QuestCard;
  timestamp: number;
}

// ==================== GAME STATE ====================

export interface GameState {
  roomId: string;
  meta: RoomMeta;
  publicBoard: PublicBoard;
  players: Record<string, Player>;
  privateRoles?: Record<string, { role: Role; team: Team; knownPlayers: string[]; knownRoles?: Record<string, Role> }>;
}

// ==================== ROLE CONFIGURATION ====================

// Role distribution based on player count (from official rules)
export const ROLE_DISTRIBUTION: Record<number, { good: number; evil: number }> = {
  5: { good: 3, evil: 2 },
  6: { good: 4, evil: 2 },
  7: { good: 4, evil: 3 },
  8: { good: 5, evil: 3 },
  9: { good: 6, evil: 4 },
  10: { good: 6, evil: 4 },
};

// Team sizes for each quest based on player count (from official rules)
export const TEAM_SIZES: Record<number, number[]> = {
  5: [2, 3, 2, 3, 3],
  6: [2, 3, 4, 3, 4],
  7: [2, 3, 3, 4, 4],
  8: [3, 4, 4, 5, 5],
  9: [3, 4, 4, 5, 5],
  10: [3, 4, 4, 5, 5],
};

// Quests that require 2 fails to fail (4th quest for 7+ players)
export const REQUIRES_TWO_FAILS: Record<number, boolean[]> = {
  5: [false, false, false, false, false],
  6: [false, false, false, false, false],
  7: [false, false, false, true, false],
  8: [false, false, false, true, false],
  9: [false, false, false, true, false],
  10: [false, false, false, true, false],
};

// Role definitions
export interface RoleDefinition {
  id: Role;
  name: string;
  nameTh: string;
  team: Team;
  description: string;
  descriptionTh: string;
  specialAbility: string;
  specialAbilityTh: string;
}

export const ROLE_DEFINITIONS: Record<Role, RoleDefinition> = {
  merlin: {
    id: 'merlin',
    name: 'Merlin',
    nameTh: 'เมอร์ลิน',
    team: 'good',
    description: 'Knows the identity of all Evil players except Mordred',
    descriptionTh: 'รู้ตัวตนของผู้เล่น Evil ทุกคนตั้งแต่ต้นเกม (ยกเว้น Mordred)',
    specialAbility: 'Sees all Minions of Mordred',
    specialAbilityTh: 'เห็นลูกสมุนของมอร์เดร็ดทั้งหมด',
  },
  percival: {
    id: 'percival',
    name: 'Percival',
    nameTh: 'เพอร์ซิวัล',
    team: 'good',
    description: 'Knows Merlin and Morgana but not which is which',
    descriptionTh: 'รู้ว่าใครเป็น Merlin แต่ไม่รู้ว่าใครเป็น Morgana',
    specialAbility: 'Sees Merlin and Morgana as two options',
    specialAbilityTh: 'เห็น Merlin และ Morgana เป็น 2 ตัวเลือก',
  },
  tristan: {
    id: 'tristan',
    name: 'Tristan',
    nameTh: 'ทริสตัน',
    team: 'good',
    description: 'Lovers with Isolde, knows each other from the start',
    descriptionTh: 'คู่รักกับอิโซลด์ รู้จักกันตั้งแต่ต้นเกม',
    specialAbility: 'Knows Isolde',
    specialAbilityTh: 'รู้จักอิโซลด์',
  },
  isolde: {
    id: 'isolde',
    name: 'Isolde',
    nameTh: 'อิโซลด์',
    team: 'good',
    description: 'Lovers with Tristan, knows each other from the start',
    descriptionTh: 'คู่รักกับทริสตัน รู้จักกันตั้งแต่ต้นเกม',
    specialAbility: 'Knows Tristan',
    specialAbilityTh: 'รู้จักทริสตัน',
  },
  loyal: {
    id: 'loyal',
    name: 'Loyal Servant',
    nameTh: 'ผู้ภักดี',
    team: 'good',
    description: 'A loyal servant of Arthur with no special abilities',
    descriptionTh: 'ผู้ภักดีของกษัตริย์อาร์เธอร์ ไม่มีความสามารถพิเศษ',
    specialAbility: 'None',
    specialAbilityTh: 'ไม่มี',
  },
  assassin: {
    id: 'assassin',
    name: 'Assassin',
    nameTh: 'มือสังหาร',
    team: 'evil',
    description: 'If Good wins 3 quests, can assassinate Merlin to win',
    descriptionTh: 'หากฝ่าย Good ชนะ 3 ภารกิจ สามารถลอบสังหาร Merlin เพื่อชนะ',
    specialAbility: 'Can assassinate Merlin at the end',
    specialAbilityTh: 'สามารถลอบสังหาร Merlin ในตอนท้าย',
  },
  morgana: {
    id: 'morgana',
    name: 'Morgana',
    nameTh: 'มอร์กาน่า',
    team: 'evil',
    description: 'Appears as Merlin to Percival, causing confusion',
    descriptionTh: 'แสดงตัวต่อ Percival เหมือนกับว่าเป็น Merlin',
    specialAbility: 'Deceives Percival',
    specialAbilityTh: 'หลอก Percival',
  },
  mordred: {
    id: 'mordred',
    name: 'Mordred',
    nameTh: 'มอร์เดร็ด',
    team: 'evil',
    description: 'Hidden from Merlin\'s sight',
    descriptionTh: 'ซ่อนตัวจากสายตาของ Merlin',
    specialAbility: 'Invisible to Merlin',
    specialAbilityTh: 'Merlin มองไม่เห็น',
  },
  oberon: {
    id: 'oberon',
    name: 'Oberon',
    nameTh: 'โอเบรอน',
    team: 'evil',
    description: 'Does not know other Evil players and they don\'t know him',
    descriptionTh: 'ไม่รู้จัก Evil คนอื่น และ Evil คนอื่นไม่รู้จักเขา',
    specialAbility: 'Isolated from other Evil',
    specialAbilityTh: 'โดดเดี่ยวจาก Evil คนอื่น',
  },
  minion: {
    id: 'minion',
    name: 'Minion of Mordred',
    nameTh: 'ลูกสมุน',
    team: 'evil',
    description: 'A loyal minion of Mordred',
    descriptionTh: 'ลูกสมุนของมอร์เดร็ด',
    specialAbility: 'Knows other Evil players',
    specialAbilityTh: 'รู้จัก Evil คนอื่น',
  },
};

// ==================== TRANSLATIONS ====================

export interface Translations {
  [key: string]: string | Translations;
}

export const TRANSLATIONS_TH: Record<string, string> = {
  'app.title': 'Avalon: The Resistance',
  'app.subtitle': 'ระบบช่วยเล่นเกมแบบ Real-time',
  
  // Lobby
  'lobby.title': 'ห้องรอผู้เล่น',
  'lobby.qrCode': 'สแกน QR Code เพื่อเข้าร่วม',
  'lobby.roomCode': 'รหัสห้อง',
  'lobby.players': 'ผู้เล่น',
  'lobby.waiting': 'รอผู้เล่น...',
  'lobby.startGame': 'เริ่มเกม',
  'lobby.minPlayers': 'ต้องมีอย่างน้อย 5 ผู้เล่น',
  'lobby.joinRoom': 'เข้าร่วมห้อง',
  'lobby.enterName': 'ใส่ชื่อของคุณ',
  'lobby.enterRoomCode': 'ใส่รหัสห้อง 6 ตัว',
  'lobby.join': 'เข้าร่วม',
  'lobby.createRoom': 'สร้างห้องใหม่',
  
  // Roles
  'role.title': 'บทบาทของคุณ',
  'role.team.good': 'ฝ่ายผู้ภักดี',
  'role.team.evil': 'ฝ่ายลูกสมุน',
  'role.holdToSee': 'กดค้างเพื่อดูบทบาท',
  'role.ready': 'พร้อม',
  'role.waitingOthers': 'รอผู้เล่นคนอื่น...',
  'role.knownPlayers': 'ผู้เล่นที่คุณรู้จัก',
  
  // Game Board
  'board.title': 'กระดานเกม',
  'board.round': 'ภารกิจที่',
  'board.leader': 'หัวหน้า',
  'board.teamSize': 'ต้องเลือก',
  'board.players': 'คน',
  'board.questSuccess': 'สำเร็จ',
  'board.questFail': 'ล้มเหลว',
  'board.currentTeam': 'ทีมปัจจุบัน',
  
  // Team Selection
  'team.select': 'เลือกทีม',
  'team.selectPlayers': 'เลือกผู้เล่น',
  'team.confirm': 'ยืนยันทีม',
  'team.waitingLeader': 'รอหัวหน้าเลือกทีม...',
  
  // Voting
  'vote.title': 'โหวตรับรองทีม',
  'vote.approve': 'เห็นด้วย',
  'vote.reject': 'ไม่เห็นด้วย',
  'vote.waiting': 'กำลังโหวต...',
  'vote.result': 'ผลโหวต',
  'vote.approved': 'ผ่าน',
  'vote.rejected': 'ตีตก',
  'vote.nextLeader': 'เปลี่ยนหัวหน้า',
  
  // Quest
  'quest.title': 'ทำภารกิจ',
  'quest.submit': 'ส่งการ์ด',
  'quest.success': 'สำเร็จ',
  'quest.fail': 'ล้มเหลว',
  'quest.waiting': 'รอสมาชิกทำภารกิจ...',
  'quest.result': 'ผลภารกิจ',
  'quest.successCount': 'สำเร็จ',
  'quest.failCount': 'ล้มเหลว',
  
  // Assassination
  'assassin.title': 'การลอบสังหาร',
  'assassin.description': 'ฝ่าย Evil ต้องเลือกว่าใครเป็น Merlin',
  'assassin.select': 'เลือกเป้าหมาย',
  'assassin.confirm': 'ยืนยันการสังหาร',
  'assassin.kill': 'สังหาร',
  
  // Game End
  'end.title': 'จบเกม',
  'end.winner': 'ผู้ชนะ',
  'end.goodWins': 'ฝ่ายผู้ภักดีชนะ',
  'end.evilWins': 'ฝ่ายลูกสมุนชนะ',
  'end.revealRoles': 'เผยโฉมบทบาท',
  'end.playAgain': 'เล่นใหม่',
  
  // Errors
  'error.roomNotFound': 'ไม่พบห้อง',
  'error.gameStarted': 'เกมเริ่มไปแล้ว',
  'error.nameRequired': 'กรุณาใส่ชื่อ',
};

export const TRANSLATIONS_EN: Record<string, string> = {
  'app.title': 'Avalon: The Resistance',
  'app.subtitle': 'Real-time Digital Assistant',
  
  // Lobby
  'lobby.title': 'Waiting Room',
  'lobby.qrCode': 'Scan QR Code to join',
  'lobby.roomCode': 'Room Code',
  'lobby.players': 'Players',
  'lobby.waiting': 'Waiting for players...',
  'lobby.startGame': 'Start Game',
  'lobby.minPlayers': 'Need at least 5 players',
  'lobby.joinRoom': 'Join Room',
  'lobby.enterName': 'Enter your name',
  'lobby.enterRoomCode': 'Enter 6-digit room code',
  'lobby.join': 'Join',
  'lobby.createRoom': 'Create New Room',
  
  // Roles
  'role.title': 'Your Role',
  'role.team.good': 'Loyal Servants',
  'role.team.evil': 'Minions of Mordred',
  'role.holdToSee': 'Hold to see role',
  'role.ready': 'Ready',
  'role.waitingOthers': 'Waiting for others...',
  'role.knownPlayers': 'Players you know',
  
  // Game Board
  'board.title': 'Game Board',
  'board.round': 'Quest',
  'board.leader': 'Leader',
  'board.teamSize': 'Select',
  'board.players': 'players',
  'board.questSuccess': 'Success',
  'board.questFail': 'Fail',
  'board.currentTeam': 'Current Team',
  
  // Team Selection
  'team.select': 'Select Team',
  'team.selectPlayers': 'Select players',
  'team.confirm': 'Confirm Team',
  'team.waitingLeader': 'Waiting for leader...',
  
  // Voting
  'vote.title': 'Vote on Team',
  'vote.approve': 'Approve',
  'vote.reject': 'Reject',
  'vote.waiting': 'Voting in progress...',
  'vote.result': 'Vote Result',
  'vote.approved': 'Approved',
  'vote.rejected': 'Rejected',
  'vote.nextLeader': 'Next Leader',
  
  // Quest
  'quest.title': 'Quest Phase',
  'quest.submit': 'Submit Card',
  'quest.success': 'Success',
  'quest.fail': 'Fail',
  'quest.waiting': 'Waiting for team members...',
  'quest.result': 'Quest Result',
  'quest.successCount': 'Success',
  'quest.failCount': 'Fail',
  
  // Assassination
  'assassin.title': 'Assassination',
  'assassin.description': 'Evil must identify Merlin',
  'assassin.select': 'Select Target',
  'assassin.confirm': 'Confirm Kill',
  'assassin.kill': 'Assassinate',
  
  // Game End
  'end.title': 'Game Over',
  'end.winner': 'Winner',
  'end.goodWins': 'Good Wins',
  'end.evilWins': 'Evil Wins',
  'end.revealRoles': 'Reveal All Roles',
  'end.playAgain': 'Play Again',
  
  // Errors
  'error.roomNotFound': 'Room not found',
  'error.gameStarted': 'Game already started',
  'error.nameRequired': 'Name is required',
};

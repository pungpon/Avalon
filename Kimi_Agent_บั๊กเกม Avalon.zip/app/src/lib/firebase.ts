// Firebase Configuration for Avalon Digital Board Game
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, get, update, onValue, off, push, serverTimestamp } from 'firebase/database';

// Firebase config from the project document
const firebaseConfig = {
  apiKey: "AIzaSyDCwxTzmE9fKf8NiDDPOSxxIPHSWQSE8mM",
  authDomain: "avalon-4569b.firebaseapp.com",
  databaseURL: "https://avalon-4569b-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "avalon-4569b",
  storageBucket: "avalon-4569b.firebasestorage.app",
  messagingSenderId: "911630934058",
  appId: "1:911630934058:web:d90e02c85fc24c688a2353",
  measurementId: "G-Y9MYXJG6T7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);

// Helper functions for database operations
export const createRoom = async (roomId: string, hostDeviceId: string, config: any) => {
  const roomRef = ref(db, `rooms/${roomId}`);
  await set(roomRef, {
    meta: {
      hostDeviceId,
      status: 'waiting',
      createdAt: serverTimestamp(),
      config,
    },
    publicBoard: {
      phase: 'lobby',
      round: 0,
      leaderId: null,
      questResults: [null, null, null, null, null],
      currentTeam: [],
      teamSize: 0,
      voteStatus: {
        total: 0,
        casted: 0,
        revealed: false,
        approveCount: 0,
        rejectCount: 0,
      },
      questStatus: {
        submitted: 0,
        required: 0,
        failCount: 0,
      },
      winner: null,
      logs: [],
      rejectedTeamsCount: 0,
      assassinationTarget: null,
    },
    players: {},
  });
  return roomId;
};

export const joinRoom = async (roomId: string, playerId: string, playerData: any) => {
  const playerRef = ref(db, `rooms/${roomId}/players/${playerId}`);
  await set(playerRef, {
    ...playerData,
    id: playerId,
    joinedAt: serverTimestamp(),
    isOnline: true,
  });
};

export const updatePlayerOnlineStatus = async (roomId: string, playerId: string, isOnline: boolean) => {
  const playerRef = ref(db, `rooms/${roomId}/players/${playerId}/isOnline`);
  await set(playerRef, isOnline);
};

export const subscribeToRoom = (roomId: string, callback: (data: any) => void) => {
  const roomRef = ref(db, `rooms/${roomId}`);
  onValue(roomRef, (snapshot) => {
    callback(snapshot.val());
  });
  return () => off(roomRef);
};

export const subscribeToPublicBoard = (roomId: string, callback: (data: any) => void) => {
  const boardRef = ref(db, `rooms/${roomId}/publicBoard`);
  onValue(boardRef, (snapshot) => {
    callback(snapshot.val());
  });
  return () => off(boardRef);
};

export const subscribeToPlayers = (roomId: string, callback: (data: any) => void) => {
  const playersRef = ref(db, `rooms/${roomId}/players`);
  onValue(playersRef, (snapshot) => {
    callback(snapshot.val());
  });
  return () => off(playersRef);
};

export const subscribeToPrivateRole = (roomId: string, playerId: string, callback: (data: any) => void) => {
  const roleRef = ref(db, `rooms/${roomId}/privateRoles/${playerId}`);
  onValue(roleRef, (snapshot) => {
    callback(snapshot.val());
  });
  return () => off(roleRef);
};

export const updatePublicBoard = async (roomId: string, updates: any) => {
  const boardRef = ref(db, `rooms/${roomId}/publicBoard`);
  await update(boardRef, updates);
};

export const updateGamePhase = async (roomId: string, phase: string) => {
  const boardRef = ref(db, `rooms/${roomId}/publicBoard/phase`);
  await set(boardRef, phase);
};

export const submitVote = async (roomId: string, round: number, playerId: string, vote: 'approve' | 'reject') => {
  const voteRef = ref(db, `rooms/${roomId}/secretVotes/${round}/${playerId}`);
  await set(voteRef, {
    playerId,
    vote,
    timestamp: serverTimestamp(),
  });
};

export const submitQuestCard = async (roomId: string, round: number, playerId: string, card: 'success' | 'fail') => {
  const cardRef = ref(db, `rooms/${roomId}/questCards/${round}/${playerId}`);
  await set(cardRef, {
    playerId,
    card,
    timestamp: serverTimestamp(),
  });
};

export const revealVotes = async (roomId: string, round: number) => {
  const votesRef = ref(db, `rooms/${roomId}/secretVotes/${round}`);
  const snapshot = await get(votesRef);
  const votes = snapshot.val() || {};
  
  const voteRecord: Record<string, 'approve' | 'reject'> = {};
  let approveCount = 0;
  let rejectCount = 0;
  
  Object.values(votes).forEach((voteData: any) => {
    voteRecord[voteData.playerId] = voteData.vote;
    if (voteData.vote === 'approve') approveCount++;
    else rejectCount++;
  });
  
  await updatePublicBoard(roomId, {
    'voteStatus.revealed': true,
    'voteStatus.approveCount': approveCount,
    'voteStatus.rejectCount': rejectCount,
    'voteStatus.votes': voteRecord,
  });
  
  return { approveCount, rejectCount, votes: voteRecord };
};

export const revealQuestCards = async (roomId: string, round: number) => {
  const cardsRef = ref(db, `rooms/${roomId}/questCards/${round}`);
  const snapshot = await get(cardsRef);
  const cards = snapshot.val() || {};
  
  const cardRecord: Record<string, 'success' | 'fail'> = {};
  let failCount = 0;
  
  Object.values(cards).forEach((cardData: any) => {
    cardRecord[cardData.playerId] = cardData.card;
    if (cardData.card === 'fail') failCount++;
  });
  
  await updatePublicBoard(roomId, {
    'questStatus.cards': cardRecord,
    'questStatus.failCount': failCount,
  });
  
  return { failCount, cards: cardRecord };
};

export const assignRoles = async (roomId: string, roles: Record<string, any>) => {
  const rolesRef = ref(db, `rooms/${roomId}/privateRoles`);
  await set(rolesRef, roles);
};

export const addLog = async (roomId: string, message: string, type: 'info' | 'success' | 'fail' | 'warning' = 'info') => {
  const logsRef = ref(db, `rooms/${roomId}/publicBoard/logs`);
  const newLogRef = push(logsRef);
  await set(newLogRef, {
    id: newLogRef.key,
    timestamp: serverTimestamp(),
    message,
    type,
  });
};

export const startGame = async (roomId: string, _playerCount: number) => {
  await update(ref(db, `rooms/${roomId}`), {
    'meta/status': 'playing',
    'publicBoard/phase': 'role-reveal',
  });
};

export const endGame = async (roomId: string, winner: 'good' | 'evil') => {
  await update(ref(db, `rooms/${roomId}`), {
    'meta/status': 'ended',
    'publicBoard/phase': 'game-end',
    'publicBoard/winner': winner,
  });
};

export const resetRoom = async (roomId: string) => {
  const roomRef = ref(db, `rooms/${roomId}`);
  const snapshot = await get(roomRef);
  const roomData = snapshot.val();
  
  if (!roomData) return;
  
  // Keep players but reset game state
  await set(roomRef, {
    meta: {
      ...roomData.meta,
      status: 'waiting',
    },
    publicBoard: {
      phase: 'lobby',
      round: 0,
      leaderId: null,
      questResults: [null, null, null, null, null],
      currentTeam: [],
      teamSize: 0,
      voteStatus: {
        total: 0,
        casted: 0,
        revealed: false,
        approveCount: 0,
        rejectCount: 0,
      },
      questStatus: {
        submitted: 0,
        required: 0,
        failCount: 0,
      },
      winner: null,
      logs: [],
      rejectedTeamsCount: 0,
      assassinationTarget: null,
    },
    players: roomData.players || {},
  });
};

export const generateRoomCode = () => {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
};

export const generatePlayerId = () => {
  return `player_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
};

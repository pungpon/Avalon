// Game Logic for Avalon Digital Board Game
// Based on official rules from avalon-game.com/wiki/rules/

import type { Role, Team, Player } from '@/types';
import { 
  ROLE_DISTRIBUTION, 
  TEAM_SIZES, 
  REQUIRES_TWO_FAILS,
  ROLE_DEFINITIONS 
} from '@/types';

// ==================== ROLE ASSIGNMENT ====================

/**
 * Assign roles to players based on player count and selected roles
 */
export const assignRoles = (
  playerIds: string[],
  selectedRoles: Role[]
): Record<string, { role: Role; team: Team; knownPlayers: string[]; knownRoles?: Record<string, Role> }> => {
  const playerCount = playerIds.length;
  const distribution = ROLE_DISTRIBUTION[playerCount];
  
  if (!distribution) {
    throw new Error(`Invalid player count: ${playerCount}`);
  }
  
  // Separate selected roles by team
  const goodRoles: Role[] = [];
  const evilRoles: Role[] = [];
  
  selectedRoles.forEach(role => {
    const roleDef = ROLE_DEFINITIONS[role];
    if (roleDef.team === 'good') {
      goodRoles.push(role);
    } else {
      evilRoles.push(role);
    }
  });
  
  // Fill remaining slots with basic roles
  while (goodRoles.length < distribution.good) {
    goodRoles.push('loyal');
  }
  while (evilRoles.length < distribution.evil) {
    evilRoles.push('minion');
  }
  
  // Shuffle roles
  const shuffledGood = shuffleArray([...goodRoles]).slice(0, distribution.good);
  const shuffledEvil = shuffleArray([...evilRoles]).slice(0, distribution.evil);
  
  // Combine and shuffle all roles
  const allRoles = shuffleArray([...shuffledGood, ...shuffledEvil]);
  
  // Create role assignments
  const assignments: Record<string, { role: Role; team: Team; knownPlayers: string[]; knownRoles?: Record<string, Role> }> = {};
  
  playerIds.forEach((playerId, index) => {
    const role = allRoles[index];
    const team = ROLE_DEFINITIONS[role].team;
    assignments[playerId] = {
      role,
      team,
      knownPlayers: [],
    };
  });
  
  // Set up knowledge for each role
  setupRoleKnowledge(assignments, playerIds);
  
  return assignments;
};

/**
 * Set up what each player knows about other players
 */
const setupRoleKnowledge = (
  assignments: Record<string, { role: Role; team: Team; knownPlayers: string[]; knownRoles?: Record<string, Role> }>,
  playerIds: string[]
) => {
  // Find special roles
  const merlinId = playerIds.find(id => assignments[id].role === 'merlin');
  const percivalId = playerIds.find(id => assignments[id].role === 'percival');
  const morganaId = playerIds.find(id => assignments[id].role === 'morgana');
  const mordredId = playerIds.find(id => assignments[id].role === 'mordred');
  const oberonId = playerIds.find(id => assignments[id].role === 'oberon');
  const tristanId = playerIds.find(id => assignments[id].role === 'tristan');
  const isoldeId = playerIds.find(id => assignments[id].role === 'isolde');
  
  // Suppress unused variable warnings (these are used in the switch cases)
  void percivalId;
  void oberonId;
  
  // Evil players (excluding Oberon)
  const evilIds = playerIds.filter(id => 
    assignments[id].team === 'evil' && assignments[id].role !== 'oberon'
  );
  
  // All evil players (including Oberon, excluding Mordred for Merlin)
  const allEvilIds = playerIds.filter(id => assignments[id].team === 'evil');
  
  playerIds.forEach(playerId => {
    const playerRole = assignments[playerId].role;
    const knownPlayers: string[] = [];
    const knownRoles: Record<string, Role> = {};
    
    switch (playerRole) {
      case 'merlin':
        // Merlin sees all Evil except Mordred
        allEvilIds.forEach(evilId => {
          if (evilId !== mordredId) {
            knownPlayers.push(evilId);
            knownRoles[evilId] = assignments[evilId].role;
          }
        });
        break;
        
      case 'percival':
        // Percival sees Merlin and Morgana (if both exist)
        if (merlinId) {
          knownPlayers.push(merlinId);
          knownRoles[merlinId] = 'merlin';
        }
        if (morganaId) {
          knownPlayers.push(morganaId);
          knownRoles[morganaId] = 'morgana';
        }
        break;
        
      case 'tristan':
        // Tristan knows Isolde
        if (isoldeId) {
          knownPlayers.push(isoldeId);
          knownRoles[isoldeId] = 'isolde';
        }
        break;
        
      case 'isolde':
        // Isolde knows Tristan
        if (tristanId) {
          knownPlayers.push(tristanId);
          knownRoles[tristanId] = 'tristan';
        }
        break;
        
      case 'assassin':
      case 'morgana':
      case 'mordred':
      case 'minion':
        // Evil players know each other (except Oberon)
        evilIds.forEach(evilId => {
          if (evilId !== playerId) {
            knownPlayers.push(evilId);
            knownRoles[evilId] = assignments[evilId].role;
          }
        });
        break;
        
      case 'oberon':
        // Oberon knows no one
        break;
        
      case 'loyal':
        // Loyal servants know no one
        break;
    }
    
    assignments[playerId].knownPlayers = knownPlayers;
    if (Object.keys(knownRoles).length > 0) {
      assignments[playerId].knownRoles = knownRoles;
    }
  });
};

/**
 * Shuffle array using Fisher-Yates algorithm
 */
const shuffleArray = <T>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

// ==================== GAME STATE HELPERS ====================

/**
 * Get team size for current quest
 */
export const getTeamSize = (playerCount: number, round: number): number => {
  const sizes = TEAM_SIZES[playerCount];
  if (!sizes) return 0;
  return sizes[round] || 0;
};

/**
 * Check if quest requires 2 fails to fail (4th quest for 7+ players)
 */
export const requiresTwoFails = (playerCount: number, round: number): boolean => {
  const requires = REQUIRES_TWO_FAILS[playerCount];
  if (!requires) return false;
  return requires[round] || false;
};

/**
 * Determine quest result based on cards played
 */
export const determineQuestResult = (
  playerCount: number,
  round: number,
  cards: Record<string, 'success' | 'fail'>
): 'success' | 'fail' => {
  const failCount = Object.values(cards).filter(card => card === 'fail').length;
  
  if (requiresTwoFails(playerCount, round)) {
    return failCount >= 2 ? 'fail' : 'success';
  }
  
  return failCount >= 1 ? 'fail' : 'success';
};

/**
 * Check if game has a winner
 */
export const checkWinner = (questResults: (null | 'success' | 'fail')[]): 'good' | 'evil' | null => {
  const successCount = questResults.filter(r => r === 'success').length;
  const failCount = questResults.filter(r => r === 'fail').length;
  
  if (successCount >= 3) return 'good';
  if (failCount >= 3) return 'evil';
  return null;
};

/**
 * Get default roles for player count
 */
export const getDefaultRoles = (playerCount: number): Role[] => {
  const distribution = ROLE_DISTRIBUTION[playerCount];
  if (!distribution) return [];
  
  const roles: Role[] = [];
  
  // Always include Merlin and Assassin
  roles.push('merlin', 'assassin');
  
  // Add Percival and Morgana for 5+ players
  if (playerCount >= 5) {
    roles.push('percival', 'morgana');
  }
  
  // Add Mordred for 7+ players
  if (playerCount >= 7) {
    roles.push('mordred');
  }
  
  // Add Oberon for 8+ players
  if (playerCount >= 8) {
    roles.push('oberon');
  }
  
  return roles;
};

/**
 * Validate team selection
 */
export const validateTeamSelection = (
  playerCount: number,
  round: number,
  selectedPlayers: string[]
): boolean => {
  const requiredSize = getTeamSize(playerCount, round);
  return selectedPlayers.length === requiredSize;
};

/**
 * Determine vote result
 */
export const determineVoteResult = (
  approveCount: number,
  rejectCount: number
): 'approved' | 'rejected' => {
  // Simple majority required
  return approveCount > rejectCount ? 'approved' : 'rejected';
};

/**
 * Check if Evil wins by 5 rejected teams
 */
export const checkEvilWinsByRejections = (rejectedTeamsCount: number): boolean => {
  return rejectedTeamsCount >= 5;
};

// ==================== SEAT MANAGEMENT ====================

/**
 * Get next leader index
 */
export const getNextLeaderIndex = (currentIndex: number, playerCount: number): number => {
  return (currentIndex + 1) % playerCount;
};

/**
 * Find player ID by seat index
 */
export const findPlayerBySeatIndex = (
  players: Record<string, Player>,
  seatIndex: number
): string | null => {
  const player = Object.values(players).find(p => p.seatIndex === seatIndex);
  return player?.id || null;
};

/**
 * Assign seat indices to players
 */
export const assignSeatIndices = (playerIds: string[]): Record<string, number> => {
  const shuffled = shuffleArray(playerIds);
  const assignments: Record<string, number> = {};
  
  shuffled.forEach((playerId, index) => {
    assignments[playerId] = index;
  });
  
  return assignments;
};

// ==================== ASSASSINATION ====================

/**
 * Check if assassination target is Merlin
 */
export const checkAssassination = (
  targetId: string,
  assignments: Record<string, { role: Role }>
): boolean => {
  return assignments[targetId]?.role === 'merlin';
};

/**
 * Find the Assassin player ID
 */
export const findAssassinId = (
  assignments: Record<string, { role: Role }>
): string | null => {
  const entry = Object.entries(assignments).find(([_, data]) => data.role === 'assassin');
  return entry?.[0] || null;
};

/**
 * Check if any Evil player can assassinate (if no specific Assassin role)
 */
export const canAnyEvilAssassinate = (
  assignments: Record<string, { role: Role; team: Team }>
): boolean => {
  // If no specific Assassin role, any Evil can do it
  return !Object.values(assignments).some(data => data.role === 'assassin');
};

// ==================== GAME PHASES ====================

export type GamePhase = 
  | 'lobby' 
  | 'role-reveal' 
  | 'team-selection' 
  | 'voting' 
  | 'quest' 
  | 'quest-result' 
  | 'assassination' 
  | 'game-end';

/**
 * Get next phase based on current phase and game state
 */
export const getNextPhase = (
  currentPhase: GamePhase,
  gameState: {
    voteResult?: 'approved' | 'rejected';
    questResult?: 'success' | 'fail';
    winner?: 'good' | 'evil' | null;
    rejectedTeamsCount?: number;
    goodWinsQuests?: number;
  }
): GamePhase => {
  switch (currentPhase) {
    case 'role-reveal':
      return 'team-selection';
      
    case 'team-selection':
      return 'voting';
      
    case 'voting':
      if (gameState.rejectedTeamsCount && gameState.rejectedTeamsCount >= 5) {
        return 'game-end';
      }
      if (gameState.voteResult === 'approved') {
        return 'quest';
      }
      return 'team-selection';
      
    case 'quest':
      return 'quest-result';
      
    case 'quest-result':
      if (gameState.winner) {
        if (gameState.winner === 'good' && gameState.goodWinsQuests === 3) {
          return 'assassination';
        }
        return 'game-end';
      }
      return 'team-selection';
      
    case 'assassination':
      return 'game-end';
      
    default:
      return currentPhase;
  }
};

// ==================== NOTIFICATION MESSAGES ====================

export const getPhaseMessage = (phase: GamePhase, language: 'th' | 'en' = 'th'): string => {
  const messages: Record<GamePhase, { th: string; en: string }> = {
    'lobby': { th: 'รอผู้เล่นเข้าร่วม', en: 'Waiting for players' },
    'role-reveal': { th: 'ดูบทบาทของคุณในมือถือ', en: 'Check your role on your phone' },
    'team-selection': { th: 'หัวหน้ากำลังเลือกทีม', en: 'Leader is selecting team' },
    'voting': { th: 'กำลังโหวตรับรองทีม', en: 'Voting on team' },
    'quest': { th: 'ทีมกำลังทำภารกิจ', en: 'Team is on quest' },
    'quest-result': { th: 'ประกาศผลภารกิจ', en: 'Quest result' },
    'assassination': { th: 'รอการลอบสังหาร', en: 'Waiting for assassination' },
    'game-end': { th: 'จบเกม', en: 'Game Over' },
  };
  
  return messages[phase][language];
};
